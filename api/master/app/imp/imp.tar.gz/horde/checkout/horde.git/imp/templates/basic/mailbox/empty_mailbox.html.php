<div class="text">
 <em>
<?php if ($this->search_mbox): ?>
  <?php echo _("No messages matched your search criteria.") ?>
<?php else: ?>
  <?php echo _("There are no messages in this mailbox.") ?>
<?php endif; ?>
 </em>
</div>
