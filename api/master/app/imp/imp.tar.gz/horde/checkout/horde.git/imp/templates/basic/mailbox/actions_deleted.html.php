<div class="control">
 <ul class="rightFloat msgactions">
  <li><?php echo $this->hide ?></li>
<?php if ($this->purge): ?>
  <li><?php echo $this->purge ?></li>
<?php endif; ?>
 </ul>
</div>
