<div class="horde-form-buttons">
 <?php echo $this->new ?>
 <?php echo $this->close ?>
</div>
