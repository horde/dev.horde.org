<div id="foldersLoading"><?php echo _("Loading...") ?></div>
<div id="foldersSidebar" style="display:none">
<?php echo $this->renderPartial('container', array('collection' => $this->containers)) ?>
</div>
