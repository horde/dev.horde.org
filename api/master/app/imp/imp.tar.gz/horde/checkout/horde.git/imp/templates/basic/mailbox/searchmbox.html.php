<div class="smallheader searchmbox">
 <?php echo $this->mbox_link ?>
</div>
