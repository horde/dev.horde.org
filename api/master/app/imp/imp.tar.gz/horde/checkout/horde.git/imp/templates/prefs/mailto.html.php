<div id="mailto_handler" style="display:none">
 <?php echo $this->hordeImage('compose.png') ?>
 <a href="#"><strong><?php printf(_("Click here to open all mailto: links using %s."), $this->name) ?></strong></a>
</div>
