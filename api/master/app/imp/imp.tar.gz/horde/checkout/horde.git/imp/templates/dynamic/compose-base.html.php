<?php echo $this->status ?>

<div id="dimpLoading">
 <?php echo _("Loading...") ?>
</div>

<div id="composeContainer" style="display:none">
 <?php echo $this->compose ?>
</div>
