<div>
 <div>
  <?php echo $this->hordeLabel('default_encrypt', _("Your default encryption method for sending messages:")) ?>
 </div>
 <div>
  <select id="default_encrypt" name="default_encrypt">
   <?php echo $this->elist ?>
  </select>
 </div>
</div>
