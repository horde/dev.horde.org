========================
 Klutz Development Team
========================


Core Developers
===============

As of the writing of this version of the document, I'm the only one.  I'll
add names as appropriate at a later time.

Marcus I. Ryan <marcus@riboflavin.net>


Drivers
=======

Marcus I. Ryan <marcus@riboflavin.net>


Localization
============

======================  ===============================================
Czech                   Pavel Chytil <pavel@chytil.tk>
Danish                  Brian Truelsen <horde+i18n@briantruelsen.dk>
Finnish                 Petteri Karttunen <pkarttun@siba.fi>
German                  Jan Schneider <jan@horde.org>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
Swedish                 Andreas Dahlén <andreas@dahlen.ws>
======================  ===============================================
