Klutz Installation Guide
Copyright 2002 <marcus@riboflavin.net>

Installation instructions for Klutz!

[Insert instructions here - if you have any, let me know ;) ]
