========================
 Agora Development Team
========================


Core Developers
===============



Drivers
=======



Localization
============

======================  ===============================================
Chinese (Traditional)   Chih-Wei Yeh <cwyeh@ccca.nctu.edu.tw>
Finnish                 Petteri Karttunen <pkarttun@siba.fi>
French                  Florent Aide <faide@alphacent.com>
German                  Jan Schneider <jan@horde.org>
Hungarian               Garami Gabor <hrgyster@gmail.com>
                        Andras Galos <galosa@netinform.hu>
Japanese                Takeshi Taguchi <taguchi@tcltk.jp>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Lithuanian              Vilius Šumskas <vilius@lnk.lt>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
Slovenian               Duck <duck@obala.net>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
Ukrainian               Andriy Kopystyansky <anri@polynet.lviv.ua>
======================  ===============================================
