<?php

require __DIR__ . '/forums.php';
