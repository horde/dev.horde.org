=============================
 Agora Development TODO List
=============================

:Contact: dev@lists.horde.org

- Add per-forum custom templates.

- Write an agorad daemon that provided access to agora forums via NNTP,
  possibly IMAP, etc.

- Split threads per page in threaded view.

- Add per-forum text filter settings.

- Add permission management interface

- Reduce number of loops in for thread display

- AJAX reply submission
