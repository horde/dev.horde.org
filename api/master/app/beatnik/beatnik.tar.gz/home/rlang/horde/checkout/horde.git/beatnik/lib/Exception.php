<?php
class Beatnik_Exception extends Horde_Exception_Wrapped
{
}