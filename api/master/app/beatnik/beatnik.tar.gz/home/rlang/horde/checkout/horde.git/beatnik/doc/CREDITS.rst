===========================
 Beatnik Development Team
===========================

Core Developers
===============
Ben Klang <bklang@alkaloid.net>
Duck <duck@obala.net>


Drivers
=======
ldap2dns - Ben Klang <bklang@alkaloid.net>
sql      - Duck <duck@obala.net>


Localization
============

=====================   ======================================================
Latvian                 Jānis Eisaks <jancs@dv.lv>
Slovenian               Duck <duck@obala.net>
Spanish                 Manuel P. Ayala <mayala@unex.es>
Hungarian               Andras Galos <galosa@netinform.hu>
=====================   ======================================================


Contributions
=============
