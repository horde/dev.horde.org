================================
 Beatnik Development TODO List
================================

* Create an api which can be used by XML-RPC where remote clients can
  authenticate to horde and update their own DNS entries (subject to built-in
  permissions scheme).

* Allow sorting on arbitrary fields

* Fix deleting entire domains
