- Integrate SpanDSP fax driver with Asterisk

- Ability to create new covers and faxes
