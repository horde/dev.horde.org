<?php define('HYLAX_VERSION', '0.1-cvs') ?>
