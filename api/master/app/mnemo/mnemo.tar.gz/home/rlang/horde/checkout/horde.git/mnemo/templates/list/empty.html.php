<p class="text"><em><?php echo _("No notes match the current criteria.") ?></em></p>
