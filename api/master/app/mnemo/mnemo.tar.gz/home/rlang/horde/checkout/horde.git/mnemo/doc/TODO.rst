=============================
 Mnemo Development TODO List
=============================

:Contact: horde@lists.horde.org

- Allow resorting search results.

- Next/Previous buttons in the note view.
