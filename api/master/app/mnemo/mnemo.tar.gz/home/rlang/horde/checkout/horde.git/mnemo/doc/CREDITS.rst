========================
 Mnemo Development Team
========================


Core Developers
===============

- Chuck Hagenbuch <chuck@horde.org>
- Jan Schneider <jan@horde.org>


Localization
============

=====================   ======================================================
Basque                  Edurne <edurne@uzei.com>
                        Ibon Igartua <ibon.igartua@ehu.eus>
Brazilian Portuguese    Antonio Dias <accdias-horde-i18n@sst.com.br>
                        Fabio Gomes <flgomes@fazenda.sp.gov.br>
                        Luis Felipe Marzagao <duli@fedoraproject.org>
                        Eduardo de Carli <carliedu@ig.com.br>
Bulgarian               Miroslav Pendev <miro@cybershade.us>
Chinese (Simplified)    Peter Wang <whw@oulink.net>
                        Anna Chen <annachen2008@yahoo.com.cn>
Chinese (Traditional)   Chih-Wei Yeh <cwyeh@ccca.nctu.edu.tw>
Croatian                Matej Vela <matej.vela@carnet.hr>
Czech                   Pavel Chytil <pavel@chytil.tk>
                        Michael Grafnetter <michael.grafnetter@outlook.com>
Danish                  Martin List-Petersen <martin@list-petersen.dk>
                        Brian Truelsen <horde+i18n@briantruelsen.dk>
                        Niels Baggesen <nba@users.sourceforge.net>
                        Erling Preben Hansen <erling@eph.dk>
Dutch                   Jan Kuipers <jrkuipers@lauwerscollege.nl>
Finnish                 Leena Heino <liinu@uta.fi>
French                  Thierry Thomas <thierry@pompo.net>
                        Patrick Abiven <patrick.abiven@apitech.fr>
                        Vincent Vinet <vvinet@revolutionlinux.com>
                        Yannick Sebastia <yannick.sebastia@ecole-navale.fr>
                        Laurent Foucher <laurent.foucher@iut-tlse3.fr>
                        Paul De Vlieger
                        <paul.de_vlieger@moniut.univ-bpclermont.fr>
German                  Jan Schneider <jan@horde.org>
Greek                   Stefanos I. Dimitriou <support_webmail@teiath.gr>
                        Silligardos Xristoforos
                        Anagnostopoulos Apostolis
                        Konstantinos C. Milosis <kmilosis@yahoo.com>
                        Giorgos Strimpakos <strimpak.geo@gmail.com>
                        Terpou Maria <mterpou@cti.gr>
                        Drakopoulos Takis <tdrakop@cti.gr>
Hungarian               Laszlo L. Tornoci <torlasz@xenia.sote.hu>
                        Andras Galos <galosa@netinform.hu>
                        Zoltán Németh <nemeth.zoltan@etit.hu>
Italian                 Sergio G. Caredda <scaredda@tiscali.it>
                        Marko Djukic <tech@oblo.com>
                        Marco Pirovano <marco.pirovano@uni-bocconi.it>
                        Cristian Manoni <cristian.manoni@nethesis.it>
                        Massimo Malabotta <mmalabotta@units.it>
                        Massimo Balestrieri <balestrieri@mag-data.com>
Japanese                Hiromi Kimura <hiromi@tac.tsukuba.ac.jp>
Korean                  Deokgon Kim <dgkim@dgkim.net>
                        Josh Kim <joshkkim@gmail.com>
Latvian                 Janis Eisaks <jancs@dv.lv>
Lithuanian              Darius Matuliauskas <darius@lnk.lt>
                        Vilius Šumskas <vilius@lnk.lt>
Norwegian Bokmaal       Torstein S. Hansen <huleboer@techbee.no>
Norwegian Nynorsk       Per-Stian Vatne <psv@orsta.org>
Polish                  Mateusz Kaminski <matipl@ds.pg.gda.pl>
                        Piotr Tarnowski <drfugazi@drfugazi.eu.org>
                        Krzysztof Kozera <krzysztof113@o2.pl>
                        Maciej Uhlig <maciej.uhlig@us.edu.pl>
Portuguese              Nuno Loureiro <nuno@co.eth.pt>
                        Manuel Menezes de Sequeira <Manuel.Sequeira>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
                        Marius Dragulescu <mariusd@urban-grafx.ro>
Russian                 Alexey Zakharov <baber@mosga.net>
Slovak                  Ivan Noris <vix@vazka.sk>
                        Martin Matuška <martin@matuska.org>
                        Jozef Sudolský <jozef.sudolsky@elbia.sk>
Slovenian               Duck <duck@obala.net>
Spanish                 Raul Alvarez Venegas <rav@tecoman.ucol.mx>
                        Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
Swedish                 Andreas Dahlén <andreas@dahlen.ws>
                        Joaquim Homrighausen <joho@webbplatsen.se>
                        Per Olof Ljungmark <peo@bsdlabs.com>
Turkish                 Istanbul Technical University IT Department
                        <itubim@itu.edu.tr>
                        Middle East Technical University <horde-tr@metu.edu.tr>
Ukrainian               Andriy Kopystyansky <anri@polynet.lviv.ua>
=====================   ======================================================
