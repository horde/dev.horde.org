===========================
 Nag Development TODO List
===========================

:Contact: nag@lists.horde.org

- Allow resorting search results.

- Send email warnings as due dates approach.

- Next/Previous buttons in the task view.

- Adopt some UI enhancements from Palm ToDo app - dropdown list of categories
  to filter by category, view tasks due today, etc.

- Ability to purge completed tasks.

- Automatically publish tasks in iCalendar format.
