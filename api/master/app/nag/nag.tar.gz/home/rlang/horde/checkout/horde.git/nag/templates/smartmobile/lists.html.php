<div id="nag-lists" data-role="page">
 <?php echo $this->smartmobileHeader(array('logout' => true, 'portal' => true, 'title' => _("Lists"))) ?>

 <div data-role="content">
  <ul data-role="listview"></ul>
 </div>
</div>
