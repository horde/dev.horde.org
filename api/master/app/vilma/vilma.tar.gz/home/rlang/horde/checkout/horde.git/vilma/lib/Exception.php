<?php
class Vilma_Exception extends Horde_Exception_Wrapped
{
}
