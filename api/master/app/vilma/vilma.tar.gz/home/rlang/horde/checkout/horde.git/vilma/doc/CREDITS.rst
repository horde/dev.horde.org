========================
 Vilma Development Team
========================


Core Developers
===============

- Marko Djukic <marko@oblo.com>
  - Initial authoring.
- Ben Klang <ben@alkaloid.net>
  - Rewrite for Aliases and Groups/Forwards


Localization
============

=====================   ======================================================
Finnish                 Leena Heino <liinu@uta.fi>
German                  Jan Schneider <jan@horde.org>
Italian                 Marko Djukic <marko@oblo.com>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Lithuanian              Vilius Šumskas <vilius@lnk.lt>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
=====================   ======================================================
