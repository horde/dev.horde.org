===========================
Vilma Development TODO List
===========================

* Implement an audit trail so that we know when and by whom accounts were
  created, deleted, modified, etc.

* Integrate with Beatnik to allow DNS zone and MX records to be created upon
  domain creation

* Abstract domains driver from accounts driver

* Create Beatnik-integrated domains driver

* Throw proper error if MySQL module not installed in PHP
