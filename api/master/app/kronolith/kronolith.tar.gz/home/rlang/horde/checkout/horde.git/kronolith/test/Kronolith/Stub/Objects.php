<?php

class Content_Objects_Manager
{
  public function delete()
  {
  }
}