<?php

class Kronolith_Stub_CalendarManager
{
    public function __construct($calendar = 'foo')
    {
    }

    public function getEntry($list, $entry)
    {
        return false;
    }

}