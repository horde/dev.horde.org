<?php

class Content_Tagger
{
    public function getTags()
    {
        return array();
    }

    public function tag()
    {
    }

    public function removeTagFromObject()
    {
    }
}