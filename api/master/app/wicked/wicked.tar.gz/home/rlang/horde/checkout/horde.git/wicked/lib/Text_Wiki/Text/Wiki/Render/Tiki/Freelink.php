<?php

require_once 'Text/Wiki/Render/Tiki/Wikilink.php';

class Text_Wiki_Render_Tiki_Freelink extends Text_Wiki_Render_Tiki_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)
}

?>