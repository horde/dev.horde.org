<br />

<div class="horde-content">
  <h3><?php echo $this->title ?></h3>
</div>

<table class="horde-table sortable" style="width:100%">
<thead>
 <tr class="nowrap">
  <th style="width:40%"><?php echo $this->th_page ?></th>
  <th style="width:10%"><?php echo $this->th_version ?></th>
  <th style="width:25%"><?php echo $this->th_author ?></th>
  <th style="width:25%"><?php echo $this->th_updated ?></th>
 </tr>
</thead>
<tbody>
