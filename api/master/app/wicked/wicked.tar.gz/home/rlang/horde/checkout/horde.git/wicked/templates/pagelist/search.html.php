<h1 class="header"><?php echo _("Search Results") ?></h1>
