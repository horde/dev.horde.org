<?php
/**
 * @package Wicked
 */
class Text_Wiki_Render_Plain_Toc2 extends Text_Wiki_Render_Plain_Toc
{
}
