<br />
<table class="horde-table sortable" style="width:100%">
<thead>
 <tr class="nowrap">
  <th style="width:40%"><?php echo _("Page") ?></th>
  <th style="width:10%"><?php echo _("Version") ?></th>
  <th style="width:25%"><?php echo _("Author") ?></th>
  <th style="width:20%"><?php echo _("Creation Date") ?></th>
<?php if ($this->hits): ?>
  <th style="width:5%"><?php echo _("Page Views") ?></th>
<?php endif ?>
 </tr>
</thead>
<tbody>
