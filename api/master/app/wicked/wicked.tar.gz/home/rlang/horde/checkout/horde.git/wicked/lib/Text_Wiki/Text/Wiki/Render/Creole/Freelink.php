<?php

require_once 'Text/Wiki/Render/Creole/Wikilink.php';

class Text_Wiki_Render_Creole_Freelink extends Text_Wiki_Render_Creole_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)
}

?>