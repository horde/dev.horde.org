<div class="pagebody">
 <?php echo $this->text ?>
</div>
