<?php

class Text_Wiki_Render_Creole extends Text_Wiki_Render {

    function pre()
    {
        return;
    }

    function post()
    {
        return;
    }

}
?>