<?php
/**
 * Base exception class for Jonah.
 *
 * Copyright 2010-2017 Horde LLC (http://www.horde.org/)
 *
 * @author  Michael J. Rubinsky <mrubinsk@horde.org>
 * @package Jonah
 */
class Jonah_Exception extends Horde_Exception_Wrapped
{
}
