==============================
 Hermes Development TODO List
==============================

:Last update:   $Date: 2008/06/25 17:20:56 $
:Revision:      $Revision: 1.11 $

- Add support for managing "time pools" such as vacation time and sick days.

- Add a request and approval mechanism (for some time pools, such as
  vacation).

- Add employee expenses.  Allow them to be billed to clients.  Add search
  and export ability for them.

- Add "Don't know" to "Billable?" options.  A manager must review and decide
  on all time before exporting.

- Allow selection of which fields to display for clients.

- Separate "review" permission into "Other People's Time" and "Submitted Time"
  permissions (and "Other People's Submitted Time"?)

- Preference to select a new entry mode where user can enter start time and
  end time (instead of number of hours).

- The client list can get quite large.  Keep the last ten MRU in the drop
  down box, with a sixth option being "More...".  Javascript will pop open a
  window with the full list (or a search window?) to cycle one into the MRU.
