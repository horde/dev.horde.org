=========================
 Hermes Development Team
=========================


Core Developers
===============

Chuck Hagenbuch <chuck@horde.org>
 - Initial code, sponsored by Hawk Technologies (http://www.hawk.com/).

Jan Schneider <jan@horde.org>
 - Maintenance, stuff.

Ben Klang <ben@alkaloid.net>
 - Hermes API and Dashboard Widget.

Michael J Rubinsky <mrubinsk@horde.org>
 - AJAX view, maintenance, other stuff.


Localization
============

=====================   ======================================================
Chinese (Traditional)   David Chang <david@tmv.gov.tw>
Finnish                 Petteri Karttunen <pkarttun@siba.fi>
German                  Jan Schneider <jan@horde.org>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
=====================   ======================================================
