<div id="rule" data-role="page">
 <?php echo $this->smartmobileHeader(array('backlink' => array('#rules', _("Rules")), 'logout' => true, 'title' => _("View Rule"))) ?>

 <div data-role="content">
  <dl>
   <dt><?php echo _("Label") ?></dt>
   <dd id="ingo-rule-label"></dd>
   <dt><?php echo _("Description") ?></dt>
   <dd id="ingo-rule-description"></dd>
  </dl>
 </div>
</div>
