============================
 Ingo Development TODO List
============================

- Better checks for bulk and mailing lists in vacation.

- A smart composite driver that would let you define seperate drivers for
  forwards, vacation, and filters.  Should also define the order of those
  backends so that Ingo only allows re-arranging of rule order within the
  correct bounds.
