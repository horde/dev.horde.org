========================
 Sesha Development Team
========================


Core Developers
===============

- Jan Schneider <jan@horde.org>
- Ralf Lang <lang@b1-systems.de>

Localization
============

=====================   ===============================================
Finnish                 Leena Heino <liinu@uta.fi>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Lithuanian              Vilius Šumskas <vilius@lnk.lt>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
=====================   ===============================================


Inactive Developers
===================

- Bo Daley <bo@darkwork.net>
- Andrew Coleman <mercury@appisolutions.net>
