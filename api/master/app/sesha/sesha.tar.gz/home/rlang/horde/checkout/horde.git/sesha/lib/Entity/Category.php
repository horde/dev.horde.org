<?php
class Sesha_Entity_Category extends Horde_Rdo_Base
{
}

