Sesha is mostly complete, especially for just keeping track of inventory. 

Here is an incomplete list of features that would be cool to have.

* Remember previous category after editing a stock item
* Search by Property Names, not just values
* Implement API for adding, updating & getting properties for items in inventory
* Add a few new Horde_Form_Types like IP address and Turba contact so that all i
  of the previous functionality from Sesha is present in this version.
* More help(?)
* Maybe a better summary that will include a set of user-defined properties to 
  show (probably will lag too much to implement)
* Add another data field to allow an item to be purchased or not (or another 
  table all together)
* Add a field allowing user to indicate how many of an item are in stock.
* Consider crossover of this app with Merk (shopping cart)


These are not set in stone, but if Sesha is going to be used to keep up with a 
*store's* inventory, these features would be nice to have. If it is nothing 
more than to keep track of a few things that are lying around, Sesha is 
already set to rock and roll.

Cheers,

Coleman
mercury [at] appisolutions [dot] net

* Horde 5 Ajax view
* Utilisation of the Rdo driver's enhanced search capabilities

Ralf Lang