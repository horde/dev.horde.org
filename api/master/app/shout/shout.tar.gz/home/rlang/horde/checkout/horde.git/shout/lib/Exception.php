<?php
class Shout_Exception extends Horde_Exception_Wrapped
{
}
