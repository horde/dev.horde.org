============================
|| Luxor Development Team ||
============================

===============
Core Developers
===============

Jan Schneider <jan@horde.org>
- initial port from LXR


============
Localization
============

Finnish                 Leena Heino <liinu@uta.fi>
German                  Jan Schneider <jan@horde.org>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
