Short term
----------
- documentation
- standard sql for sql scripts
- PEAR::DB sequences instead of autoincrement fields
- port UI

Mid term
--------
- CVS File driver

Long term
---------
- branch support
