======================
 Sam Development Team
======================


Core Developers
===============

Chris Bowlby <excalibur@hub.org>

- Main programmer, designer.

Max Kalika <max@horde.org>

- Horde_Form rewrite, amavisd-new sql driver.


Interface Designers
===================

Marc Fournier <scrappy@hub.org>

- Main interface designer.


Database Contributors
=====================

Devin Drown <drown@banzai.org>

- MySQL Database Schema


Localization
============

======================  ===============================================
Chinese Traditional     David Chang <david@tmv.gov.tw>
Czech                   T. Macek <maca02@atlas.cz>
Estonian                Alar Sing <alar.sing@err.ee>
Finnish                 Petteri Karttunen <pkarttun@siba.fi>
French                  Thierry Thomas <thierry@pompo.net>
German                  Jan Schneider <jan@horde.org>
Hungarian               Andras Galos <galosa@netinform.hu>
Italian                 Marco Favero <falon@csi.it>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Norwegian Nynorsk       Per-Stian Vatne <psv@orsta.org>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
======================  ===============================================
