====================================================
|| The Spam Assassin Module Development TODO List ||
====================================================

- Add means to be able to delete preferences, to re-enable system defaults.
- Add help items for all the known attributes.
- Add amavisd-new ldap storage driver.
