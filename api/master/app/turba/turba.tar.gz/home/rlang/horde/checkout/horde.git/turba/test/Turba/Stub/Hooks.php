<?php
/**
 * Turba hooks configuration file.
 */
class Turba_Hooks
{
}
