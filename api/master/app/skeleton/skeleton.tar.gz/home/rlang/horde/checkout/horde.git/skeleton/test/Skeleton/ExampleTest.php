<?php
/**
 * @author     Your Name <you@example.com>
 * @license    http://www.horde.org/licenses/gpl GPL
 * @category   Horde
 * @package    Skeleton
 * @subpackage UnitTests
 */

class Skeleton_ExampleTest extends Horde_Test_Case
{
    public function setUp()
    {
    }

    public function testSomething()
    {
    }

    public function tearDown()
    {
    }
}
