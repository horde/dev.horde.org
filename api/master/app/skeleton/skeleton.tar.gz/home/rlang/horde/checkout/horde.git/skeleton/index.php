<?php
/**
 * Skeleton index script.
 *
 * Copyright 2007-2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (GPL). If you
 * did not receive this file, see http://www.horde.org/licenses/gpl.
 *
 * @author Your Name <you@example.com>
 */

require __DIR__ . '/list.php';
