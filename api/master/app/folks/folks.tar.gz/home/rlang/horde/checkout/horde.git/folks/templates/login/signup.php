<?php

echo $tabs->render();
$form->renderActive(null, null, null, 'post');
