===========================
 Folks Development Team
===========================


Core Developers
===============
Duck <duck@obala.net>
Jan Zagar <jan.zagar@siol.net>


Drivers
=======
Duck <duck@obala.net>


Localization
============

=====================   ======================================================
Latvian                 Jānis Eisaks <jancs@dv.lv>
Slovenian               Duck <duck@obala.net>
Spanish                 Manuel P. Ayala <mayala@unex.es>
=====================   ======================================================

Contributions
=============

