<h1><?php echo $title ?></h1>

<ul class="notices">
 <li>
  <?php echo Horde::img('alerts/warning.png') . sprintf(_("User %s has been disabled."), $user) ?>
 </li>
</ul>
