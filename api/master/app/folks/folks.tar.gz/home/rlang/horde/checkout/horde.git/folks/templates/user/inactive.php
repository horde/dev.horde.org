<h1><?php echo $title ?></h1>

<ul class="notices">
 <li>
  <?php echo Horde::img('alerts/warning.png') . sprintf(_("User %s is inactive."), $user) ?>
 </li>
</ul>
