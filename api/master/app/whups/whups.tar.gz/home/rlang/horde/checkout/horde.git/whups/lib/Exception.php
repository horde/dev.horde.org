<?php
class Whups_Exception extends Horde_Exception_Wrapped
{
}
