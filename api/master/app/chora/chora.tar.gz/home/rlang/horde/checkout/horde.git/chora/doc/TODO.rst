=============================
 Chora Development TODO List
=============================

:Contact: chora@lists.horde.org

- Other utility support (lint support for C files, pod2html for perl, PHPDoc
  for PHP).

- Provide compressed versions of files/directories on a given tag, for
  downloading.

- Provide a database and caching backend for advanced searching.

- Generate per-directory and per-repository visual branch views, instead of
  only per-file.

- CVS search: http://cvssearch.sourceforge.net/

- Stats: http://sourceforge.net/projects/statcvs/

- Feature ideas: http://www.cenqua.com/fisheye/features.html
