=================
 Upgrading Chora
=================

:Contact: chora@lists.horde.org

.. contents:: Contents
.. section-numbering::


General instructions
====================

These are instructions to upgrade from earlier Chora versions.

After updating to a newer Chora version, you **always** need to update
configurations. Log in as an administrator, go to Administration =>
Configuration and update anything that's highlighted as outdated.


Upgrading Chora from 2.x to 3.x
===============================

This is a non-exhaustive, quick explanation of what has changed between a Chora
2.x installation to Chora 3.x.


Configuration files
-------------------

The ``config/sourceroots.php`` configuration file has been renamed to
``config/backends.php``.
