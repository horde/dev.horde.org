========================
 Chora Development Team
========================

Based on an perl script written by Bill Fenner <fenner@parc.xerox.com>, and
Human-Readable diff code by H. Zeller <zeller@think.de>

Charles Hagenbuch <chuck@horde.org> then did the initial port from perl to
PHP.

Anil Madhavapeddy <anil@recoil.org> cleaned it up, added template support,
figured it needed a rewrite.  And thus came along the CVSLib library and the
current incarnation of the viewer.

Inspiration for the annotation portions came from examining Bill Fenner's
original cvsweb script again, and looking at the 'cvs server' implementation.

Initial Subversion support was written by "Jay Freeman (saurik)"
<saurik@saurik.com>.

Continuing development has mainly been performed by Chuck Hagenbuch and
Jan Schneider <jan@horde.org>.  Michael Slusarz has chipped in here and there
and has helped to reorganize the code to allow Git to be added to the list
of available VCS drivers.


Localization
============

=====================   ======================================================
Brazilian Portuguese    Antonio Dias <accdias@sst.com.br>
                        garnier@hmg.click21.com.br
Chinese (Simplified)    Liaobin <liaobin@jite.net>
Chinese (Traditional)   Lin Zhemin <ljm@ljm.idv.tw>
Czech                   Pavel Chytil <paja@asp.ogi.edu>
Danish                  Brian Truelsen <horde+i18n@briantruelsen.dk>
Dutch                   Jan Kuipers <jrkuipers@lauwerscollege.nl>
Finnish                 Tero Matinlassi <tero.matinlassi@edu.vantaa.fi>
                        Leena Heino <leena.heino@uta.fi>
French                  Mathieu Arnold <mat@absolight.net>
German                  Jan Schneider <jan@horde.org>
Italian                 Fabio Pedretti <fabio.pedretti@ing.unibs.it>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Norwegian Bokmaal       Oystein Steimler <oystein@rexta.net>
Polish                  Piotr Roszatycki <Piotr_Roszatycki@netia.net.pl>
Romanian                Eugen Hoanca <eugenh@urban-grafx.ro>
                        Marius Dragulescu <mariusd@urban-grafx.ro>
Russian                 Illya Belov <belov@iop.irkps.ru>
Slovak                  Ivan Noris <vix@vazka.sk>
Spanish                 Julian Jares <jjares@techie.com>
                        Manuel Perez Ayala <mperaya@alcazaba.unex.es>
Swedish                 Andreas Dahlén <andreas@dahlen.ws>
=====================   ======================================================
