<?php
$theme_name = _("Default");
