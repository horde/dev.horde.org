<div id="horde-sub">
  <div id="horde-date"><?php echo $this->date ?></div>
  <div id="horde-info"><?php echo $this->subinfo ?></div>
</div>
