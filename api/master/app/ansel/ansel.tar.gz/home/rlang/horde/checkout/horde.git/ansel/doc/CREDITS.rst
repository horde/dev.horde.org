========================
 Ansel Development Team
========================


Core Developers
===============

- Chuck Hagenbuch <chuck@horde.org>
- Michael J. Rubinsky <mrubinsk@horde.org>


Localization
============

======================  ===============================================
Chinese (Traditional)   David Chang <david@tmv.gov.tw>
Danish                  Erling Preben Hansen <erling@eph.dk>
Finnish                 Leena Heino <liinu@uta.fi>
French                  Maxime Chavagne <maxime@chavagne.net>
                        Paul De Vlieger
                        <paul.de_vlieger@moniut.univ-bpclermont.fr>
German                  Jan Schneider <jan@horde.org>
Japanese                Takeshi Taguchi <taguchi@tcltk.jp>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Lithuanian              Vilius Šumskas <vilius@lnk.lt>
Slovak                  Martin Matuška <martin@matuska.org>
                        Jozef Sudolský <jozef.sudolsky@elbia.sk>
Slovenian               Duck <duck@obala.net>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
Swedish                 Andreas Dahlén <andreas@dahlen.ws>
Turkish                 Akif Dinc <akif@dinc.org>
======================  ===============================================
