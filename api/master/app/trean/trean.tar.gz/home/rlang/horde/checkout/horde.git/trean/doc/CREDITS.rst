========================
 Trean Development Team
========================


Core Developers
===============

- Chuck Hagenbuch <chuck@horde.org>
- Michael J. Rubinsky <mrubinsk@horde.org>
- Jan Schneider <jan@horde.org>


Localization
============

=====================   ======================================================
Basque                  Ibon Igartua <ibon.igartua@ehu.eus>
Chinese (Traditional)   Chih-Wei Yeh <cwyeh@ccca.nctu.edu.tw>
                        David Chang <david@tmv.gov.tw>
Danish                  Erling Preben Hansen <erling@eph.dk>
Dutch                   Han Spruyt <han.spruyt@ijsselgroep.nl>
Finnish                 Leena Heino <Leena.Heino@uta.fi>
French                  Raphaël Jeudy <raphael.jeudy@fastorama.com>
German                  Jan Schneider <jan@horde.org>
Greek                   Giorgos Strimpakos <strimpak.geo@gmail.com>
                        Terpou Maria <mterpou@cti.gr>
                        Drakopoulos Takis <tdrakop@cti.gr>
Hungarian               Andras Galos <galosa@netinform.hu>
Italian                 Sergio G. Caredda <scaredda@tiscali.it>
                        Marko Djukic <marko@oblo.com>
                        Marco Pirovano <marco.pirovano@unibocconi.it>
                        Massimo Balestrieri <balestrieri@mag-data.com>
Latvian                 Janis Eisaks <je@ktf.rtu.lv>
Norwegian Bokmaal       Odd Marthon Lende <dreden@dreden.com>
Polish                  Piotr Adamcio <adamcios@o2.pl>
Slovenian               Duck <duck@obala.net>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
                        Juan C. Blanco <jcblanco@fi.upm.es>
Swedish                 Andreas Dahlén <andreas@dahlen.ws>
Turkish                 Middle East Technical University <horde-tr@metu.edu.tr>
=====================   ======================================================


Inactive Developers
===================

- Mike Cochrane <mike@graftonhall.co.nz>

  - original code

- Ben Chavet

