<?php if ($this->noterror): ?>
<table width="100%" cellspacing="0">
 <tr>
  <td class="header">
   <?php echo $this->title; ?>
  </td>
 </tr>
 <tr>
  <td>
   <?php echo $this->main; ?>
   </td>
 </tr>
</table>
<?php endif; ?>
