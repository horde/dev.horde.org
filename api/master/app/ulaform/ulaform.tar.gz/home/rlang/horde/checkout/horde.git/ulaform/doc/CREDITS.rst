==========================
 Ulaform Development Team
==========================


Core Developers
===============

Brent J. Nordquist <bjn@horde.org>
- Ulaform concept.
- Original code.

Chuck Hagenbuch <chuck@horde.org>
- Horde_Form:: work.

Marko Djukic <marko@oblo.com>
- More Horde_Form:: work.
- Horde_Template:: support.


Localization
============

=====================   ======================================================
Chinese (Traditional)   David Chang <david@tmv.gov.tw>
Finnish                 Petteri Karttunen <pkarttun@siba.fi>
German                  Jan Schneider <jan@horde.org>
Italian                 Marko Djukic <marko@oblo.com>
Latvian                 Jānis Eisaks <jancs@dv.lv>
Lithuanian              Vilius Šumskas <vilius@lnk.lt>
Spanish                 Manuel Perez Ayala <mperaya@alcazaba.unex.es>
=====================   ======================================================
