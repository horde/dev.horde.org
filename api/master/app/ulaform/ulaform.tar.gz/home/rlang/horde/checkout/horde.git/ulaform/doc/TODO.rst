===============================
 Ulaform Development TODO List
===============================

:Contact: horde@lists.horde.org

- Allow for users embedding the form to specify the action.

- Create a separate jsdisplay.php for displaying a form through
javascript inside <div> tags.

- Allow XML definitions of forms as well as database.

- Documentation
