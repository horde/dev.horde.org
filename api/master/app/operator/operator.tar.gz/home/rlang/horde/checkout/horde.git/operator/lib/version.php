<?php define('OPERATOR_VERSION', '0.1-cvs') ?>
