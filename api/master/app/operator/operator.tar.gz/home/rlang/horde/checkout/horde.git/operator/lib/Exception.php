<?php
class Operator_Exception extends Horde_Exception_Wrapped
{
}
