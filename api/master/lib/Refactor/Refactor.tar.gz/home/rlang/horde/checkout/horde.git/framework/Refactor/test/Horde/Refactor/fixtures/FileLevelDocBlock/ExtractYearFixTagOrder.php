<?php
/**
 * Copyright 2001-2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (LGPL). If you
 * did not receive this file, see http://www.horde.org/licenses/lgpl.
 *
 * Descriptions.
 *
 * @license   http://www.horde.org/licenses/bsd BSD
 * @category  Horde
 * @package   Foobar
 * @author    Jan Schneider <jan@horde.org>
 */

/**
 * Summary.
 *
 * Descriptions.
 *
 * @package   Foobar
 * @author    Jan Schneider <jan@horde.org>
 * @license   http://www.horde.org/licenses/bsd BSD
 * @category  Horde
 */
class Foo
{
}
