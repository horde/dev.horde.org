<?php
/**
 * Summary.
 *
 * Descriptions.
 *
 * @author    Jan Schneider <jan@horde.org>
 * @category  Horde
 * @copyright 2017 Horde LLC
 * @license   http://www.horde.org/licenses/bsd BSD
 * @package   Foobar
 */
class Foo
{
}
