<?php
/**
 * Copyright 2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (...). If you
 * did not receive this file, see http://www.horde.org/licenses/....
 *
 * @author   
 * @category Horde
 * @license  http://www.horde.org/licenses/... ...
 * @package  
 */

/**
 * Summary
 *
 * @author    
 * @category  Horde
 * @copyright 2017 Horde LLC
 * @license   http://www.horde.org/licenses/... ...
 * @package   
 */
class Foo
{
}
