<?php
class Foo extends Bar
{
    /**
     * Constructor.
     */
    public function Foo(Bar $bar, $x = null)
    {
        parent::Bar($bar);
    }
}
