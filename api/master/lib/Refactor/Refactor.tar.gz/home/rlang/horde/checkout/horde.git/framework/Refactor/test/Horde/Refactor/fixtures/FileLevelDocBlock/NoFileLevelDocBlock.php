<?php
class Foo
{
}
