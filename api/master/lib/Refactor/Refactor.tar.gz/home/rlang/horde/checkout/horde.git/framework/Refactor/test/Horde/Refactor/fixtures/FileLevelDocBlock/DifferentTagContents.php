<?php
/**
 * Copyright 2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (LGPL). If you did
 * not receive this file, see http://www.horde.org/licenses/lgpl21.
 *
 * @author   Some Author <author@acme.org>
 * @category Horde
 * @license  http://www.horde.org/licenses/lgpl21 LGPL-2.1
 * @package  Auth
 */

/**
 * This class does stuff.
 *
 * @author    Some Author <author@acme.org>
 * @category  Horde
 * @license   http://www.horde.org/licenses/gpl GPL
 * @copyright 2017 Horde LLC
 * @package   Auth
 */
class Foo
{
}
