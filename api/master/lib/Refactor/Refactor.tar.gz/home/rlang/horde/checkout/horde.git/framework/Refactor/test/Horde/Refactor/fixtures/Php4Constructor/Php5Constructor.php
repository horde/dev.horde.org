<?php
class Foo
{
    /**
     * Constructor.
     */
    public function __construct()
    {
    }
}
