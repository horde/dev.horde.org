<?php
/**
 * File summary.
 *
 * File Descriptions.
 *
 * @copyright Jan Schneider <jan@horde.org>
 */

/**
 * Class summary.
 *
 * File Descriptions.
 *
 * @license FooBar
 * @license FooBar
 */
class Foo
{
}
