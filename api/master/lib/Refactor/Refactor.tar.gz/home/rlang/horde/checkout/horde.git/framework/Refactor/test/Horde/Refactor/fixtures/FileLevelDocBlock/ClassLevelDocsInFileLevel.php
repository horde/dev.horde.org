<?php
/**
 * Summary
 *
 * Copyright 2011 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL). If you
 * did not receive this file, see http://www.horde.org/licenses/apache.
 *
 * @author
 * @category Horde
 * @license  http://www.horde.org/licenses/... ...
 * @package
 */

/**
 * @author
 * @category  Horde
 * @copyright 2011 Horde LLC
 * @license   http://www.horde.org/licenses/... ...
 * @package
 */
class Foo
{
}
