<?php
/**
 * @category   Horde
 * @package    Compress_Fast
 * @subpackage UnitTests
 */

/**
 * @category   Horde
 * @package    Compress_Fast
 * @subpackage UnitTests
 */
class Horde_Compress_Fast_Driver_LzfTest
extends Horde_Compress_Fast_Driver_TestBase
{
    protected $classname = 'Horde_Compress_Fast_Lzf';
}
