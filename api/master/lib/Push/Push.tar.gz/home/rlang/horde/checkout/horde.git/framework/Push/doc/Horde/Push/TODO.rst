Push interface

 (1) Summary
 (2) Content [MIME?]

 - Reference
 - Tags
 - ACL
 - (Location) 
 - (Images) [MIME?]
 - (Attachments) [MIME?]

Services

 (1) Twitter  (Brevity)
 (2) Facebook (ACL?)
 (3) E-Mail
 (4) Blogger
 (5) Google+
 (6) (LinkedIn)
 (7) (Xing)

Q?

 - Config?
