======================
 Documentation origin
======================

Some of the Horde component documentation is maintained in the Horde
wiki. The following list indicates the source locations for some of
the files in this directory.

:`doc/Horde/Pear/README`_: README
:`doc/Horde/Pear/REMOTE_PEAR_SERVER`_: REMOTE_PEAR_SERVER

.. _doc/Horde/Pear/README: http://wiki.horde.org/Doc/Dev/HordePear?actionID=export&format=rst
.. _doc/Horde/Pear/REMOTE_PEAR_SERVER: http://wiki.horde.org/Doc/Dev/HordePear/REMOTE_PEAR_SERVER?actionID=export&format=rst
