============================
 Pear Development TODO List
============================

- Allow reading v1 package.xml files.
- Clean up the Horde_Pear_Package_Xml API
