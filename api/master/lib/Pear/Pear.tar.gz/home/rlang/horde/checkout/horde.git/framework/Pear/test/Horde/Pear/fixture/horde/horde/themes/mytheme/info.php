<?php
$theme_name = 'My Theme';
