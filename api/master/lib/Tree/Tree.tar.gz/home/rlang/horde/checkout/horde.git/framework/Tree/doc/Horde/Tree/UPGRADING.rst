======================
 Upgrading Horde_Tree
======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.0
================

  - The tree renderers have been separated from the tree
    representation. Horde_Tree represents a tree structure. The
    Horde_Tree_Render_* classes are the actual tree renderers.

  - Horde_Tree::factory() is now Horde_Tree_Renderer::factory() and
    has a different signature.

  - The Horde_Tree_Renderer constructor has a different signature than
    the old Horde_Tree constructor.

  - The Horde_Tree::EXTRA_* constants are now called
    Horde_Tree_Renderer::EXTRA_*.

  - Horde_Tree::addNode() takes a single hash as the parameter now.
