====================================
 Kolab_Server Development TODO List
====================================

 - Ensure getBaseUid always returns a value (see
   Kolab_Freebusy/lib/Horde/Kolab/FreeBusy/Access.php)

 - Ensure the correct hostnames for a user get returned (getServer).

 - Implement currently missing scenarios.

 - Implement Kolab-webadmin functions

 - Check Kolab-webadmin patches in Kolab issue tracker.

 - Check with current HEAD applications.

 - Implement initial server bootstrap

 - Load-Balancing.

 - Read entry after writing and detect inconsistencies.

 - Password history support

 - Support alias attribute names

 - Support size restrictions.

 - Implement search result caching.

 - Remove Horde_Date dependency.
