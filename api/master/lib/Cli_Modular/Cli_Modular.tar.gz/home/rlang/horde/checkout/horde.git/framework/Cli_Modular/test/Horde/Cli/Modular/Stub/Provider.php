<?php

class Horde_Cli_Modular_Stub_Provider
extends Horde_Cli_Modular_ModuleProvider
{
    public function __construct()
    {
    }
}
