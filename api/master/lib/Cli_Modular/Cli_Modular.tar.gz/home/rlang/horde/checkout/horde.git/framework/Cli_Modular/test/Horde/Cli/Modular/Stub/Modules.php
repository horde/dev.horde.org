<?php

class Horde_Cli_Modular_Stub_Modules
extends Horde_Cli_Modular_Modules
{
    public function __construct()
    {
    }
}
