======================
 Documentation origin
======================

Some of the Horde component documentation is maintained in the Horde
wiki. The following list indicates the source locations for some of
the files in this directory.

:`doc/Horde/Cli/Modular/README`_: README

.. _doc/Horde/Cli/Modular/README: http://wiki.horde.org/Doc/Dev/HordeCliModular?actionID=export&format=rst
