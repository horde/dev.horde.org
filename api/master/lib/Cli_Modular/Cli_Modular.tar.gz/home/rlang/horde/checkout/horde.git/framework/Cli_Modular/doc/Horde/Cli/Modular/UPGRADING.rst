=============================
 Upgrading Horde_Cli_Modular
=============================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.1.0
==================

  - Horde_Cli_Modular_ModuleUsage

    This interface has been added.

  - Horde_Cli_Modular

    - __construct()

      The 'cli' parameter has been added.
