=======================
 Upgrading Horde_Share
=======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.2
================

  - Horde_Share_Base

    - fromHash()

      This method has been added.

  - Horde_Share_Object

    - toHash()

      This method has been added.
