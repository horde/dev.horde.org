<?php

class Horde_Share_Stub_Group extends Horde_Group_Mock
{
    protected $_groups = array('mygroup' => array('name' => 'mygroup',
                                                  'users' => array('john')));
}
