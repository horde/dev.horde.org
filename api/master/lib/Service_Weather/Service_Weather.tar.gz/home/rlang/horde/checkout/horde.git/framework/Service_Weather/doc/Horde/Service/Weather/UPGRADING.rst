=================================
 Upgrading Horde_Service_Weather
=================================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.0.1
==================

Support for Google's now dead weather API has been removed.
