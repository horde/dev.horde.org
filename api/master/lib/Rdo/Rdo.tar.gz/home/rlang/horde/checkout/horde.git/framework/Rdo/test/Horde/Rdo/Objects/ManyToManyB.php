<?php

class Horde_Rdo_Test_Objects_ManyToManyB extends Horde_Rdo_Base
{
}
