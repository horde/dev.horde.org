<?php
class Horde_Rdo_Test_Objects_RelatedThingMapper extends Horde_Rdo_Mapper
{
    /**
     * Inflector doesn't support Horde-style tables yet
     */
     protected $_table = 'test_relatedthings';
}
