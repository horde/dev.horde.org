<?php
class Horde_Rdo_Test_Objects_SimpleMapper extends Horde_Rdo_Mapper
{
     protected $_table = 'horde_rdo_test';
}
