=====================
 Upgrading Horde_Rdo
=====================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.1.0
==================

  - Horde_Rdo_Base

    - The toArray() method has been added.
