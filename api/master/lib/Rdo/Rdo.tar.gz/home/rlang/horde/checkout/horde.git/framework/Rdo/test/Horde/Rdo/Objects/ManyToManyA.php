<?php

class Horde_Rdo_Test_Objects_ManyToManyA extends Horde_Rdo_Base
{
}
