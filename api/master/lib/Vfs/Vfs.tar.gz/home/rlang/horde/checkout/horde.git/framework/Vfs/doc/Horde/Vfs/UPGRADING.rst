=====================
 Upgrading Horde_Vfs
=====================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.0
================

  - Horde_Vfs_Browser, Horde_Vfs_ListItem, Horde_Vfs_Object

    These classes have been removed.

  - Horde_Vfs_Base#getFolderSize()

    The $name argument has been removed, specify the full path with the first
    argument instead.

  - Horde_Vfs_Base#listFolders()

    The method has been removed. Use listFolder() with the $dironly argument
    instead.
