======================
 Upgrading Horde_Argv
======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.1.0
==================

  - Horde_Argv_HelpFormatter

    - highlightHeading(), highlightOption()

      These methods have been added.

    - __construct()

      The $color parameter has been added.
