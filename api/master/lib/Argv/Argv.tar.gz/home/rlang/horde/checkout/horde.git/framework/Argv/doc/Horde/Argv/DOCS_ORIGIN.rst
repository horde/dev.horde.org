======================
 Documentation origin
======================

Some of the Horde component documentation is maintained in the Horde
wiki. The following list indicates the source locations for some of
the files in this directory.

:`doc/Horde/Argv/README`_: README
:`doc/Horde/Argv/ADVANCED`_: ADVANCED
:`doc/Horde/Argv/EXTEND`_: EXTEND
:`doc/Horde/Argv/CALLBACKS`_: CALLBACKS

.. _doc/Horde/Argv/README: http://wiki.horde.org/Doc/Dev/HordeArgv?actionID=export&format=rst
.. _doc/Horde/Argv/ADVANCED: http://wiki.horde.org/Doc/Dev/HordeArgvAdvanced?actionID=export&format=rst
.. _doc/Horde/Argv/EXTEND: http://wiki.horde.org/Doc/Dev/HordeArgvExtend?actionID=export&format=rst
.. _doc/Horde/Argv/CALLBACKS: http://wiki.horde.org/Doc/Dev/HordeArgvCallbacks?actionID=export&format=rst
