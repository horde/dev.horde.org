TODOs
-----


- handle recurring events
- handle alarms in sync4j

- review session handling.
   - Deal with "unfinished" sessions after incomplete sync.
   - use cookies where possible. Otherwise concurrent sessions with
     device ID "sc-pim-outlook" will cause trouble big time.

- implement BUSY feature

- try to speedup data retrival inside horde

- create configuration in horde preferences: allow fancy stuff like
  "delete calendar entries from clients for events n days in the past"

- create page to view summary of previous sync and ultimately handle
  collisions as well...

- get vcard/icalendar handling right: support ical 1.0/2.0 and vcard
  2.1/3.0 creation.

Redesign / Refactoring
----------------------


-concentrate business logic where possible (controller class),
 seperate xml parsing/creation from business logic
