<?php
/**
 * Setup autoloading for the tests.
 *
 * @category Horde
 * @package  Notification
 * @author   Gunnar Wrobel <wrobel@pardus.de>
 * @license  http://www.horde.org/licenses/lgpl21 LGPL 2.1
 */

/** Needed for PEAR_Error. */
@include_once 'PEAR.php';
