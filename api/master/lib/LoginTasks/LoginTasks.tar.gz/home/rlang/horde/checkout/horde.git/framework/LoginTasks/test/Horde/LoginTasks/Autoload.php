<?php
/**
 * Setup autoloading for the tests.
 *
 * @category Horde
 * @package  LoginTasks
 * @author   Gunnar Wrobel <wrobel@pardus.de>
 * @license  http://www.horde.org/licenses/lgpl21 LGPL 2.1
 */

require_once __DIR__ . '/Stubs.php';
