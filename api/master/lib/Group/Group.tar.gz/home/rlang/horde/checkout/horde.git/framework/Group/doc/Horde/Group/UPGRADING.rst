=======================
 Upgrading Horde_Group
=======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.1
================

  - Horde_Group_* constructors

    The 'cache' element has been added to the $params argument to optionally
    pass a Horde_Cache instance to enable group caching.
