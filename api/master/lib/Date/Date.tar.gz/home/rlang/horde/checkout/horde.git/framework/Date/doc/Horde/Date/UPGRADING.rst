======================
 Upgrading Horde_Date
======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.4.0
==================

  - Horde_Date_Recurrence

    - toHash(), fromHash()

      These method have been added.


Upgrading to 2.3.0
==================

  - Horde_Date

    - getTimezoneAlias()

      This method has been added.


Upgrading to 2.2.0
==================

  - Horde_Date

    - isEqual()

      This method has been added.


Upgrading to 2.2.0
==================

  - Horde_Date

    - setNthWeekday()

      The $nth parameter accepts negative values.

  - Horde_Recurrence

    - RECUR_MONTHLY_LAST_WEEKDAY

      This constant has been added as a possible value for the $recurType
      property.


Upgrading to 2.0.0
==================

  - Horde_Date_Recurrence

    - toHash(), fromHash()

      These method have been renamed to toKolab() and fromKolab(), because the
      hash format is really Kolab-specific.
