<?php

class Horde_Kolab_Format_Stub_Types
{
}

class Horde_Kolab_Format_Stub_Types_V1
{
}

class Horde_Kolab_Format_Stub_Types_V2
{
}