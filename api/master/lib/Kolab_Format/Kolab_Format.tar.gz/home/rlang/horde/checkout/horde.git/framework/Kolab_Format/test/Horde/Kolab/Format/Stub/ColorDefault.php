<?php

class Horde_Kolab_Format_Stub_ColorDefault
extends Horde_Kolab_Format_Xml_Type_Color
{
    protected $element = 'Horde_Kolab_Format_Xml_Type_String_MaybeMissing';
    protected $value = Horde_Kolab_Format_Xml::VALUE_DEFAULT;
    protected $default = '#abcdef';
}
