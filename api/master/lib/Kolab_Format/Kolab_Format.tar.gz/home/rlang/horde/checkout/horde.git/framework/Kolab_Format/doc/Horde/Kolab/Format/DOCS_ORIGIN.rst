======================
 Documentation origin
======================

Some of the Horde component documentation is maintained in the Horde
wiki. The following list indicates the source locations for some of
the files in this directory.

:`doc/Horde/Kolab/Format/README`_: README

.. _doc/Horde/Kolab/Format/README: http://wiki.horde.org/Doc/Dev/HordeKolabFormat?actionID=export&format=rst
