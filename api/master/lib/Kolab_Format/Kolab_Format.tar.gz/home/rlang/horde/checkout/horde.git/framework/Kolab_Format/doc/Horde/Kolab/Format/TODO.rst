====================================
 Kolab_Format Development TODO List
====================================

 - Check kolab/issue4672 (Kolab_Format has encoding problems)

 - Check kolab/issue4700 (Kolab_Format problems in e-mails fetching process)

 - Developer documentation

 - Test coverage

 - PHPdoc check

 - Additional KEPs

   - ...

 - Do not overwrite multiple entries

 - Extract Xml_* subtypes to Xml_Type_Composite_* types?

 - Improved error handling? Logging strict errors?

 - Think about storing the data in iCal format.
