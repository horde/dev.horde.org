=======================
 Upgrading Horde_Alarm
=======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.2.9
==================

  - Horde_Alarm

    - getErrors()

      The keys of the returned error list contains the alarm ID now, suffixed
      by a NUL character and some alarm method suffix.


Upgrading to 2.2
================

  - Horde_Alarm

    - get(), set()

      Added the 'instanceid' member to the alarm hash.

    - exists()

      Added the $instanceid parameter.


Upgrading to 2.1
================

  - Horde_Alarm

    - getErrors()

      This method has been added.
