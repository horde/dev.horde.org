======================
 Upgrading Horde_Idna
======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 1.1.0
==================

  - Horde_Idna_Translation

    This class has been added.
