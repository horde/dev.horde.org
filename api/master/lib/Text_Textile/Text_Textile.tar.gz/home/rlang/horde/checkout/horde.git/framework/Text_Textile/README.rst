_____________
T E X T I L E

A Humane Web Text Generator

Version 2.0

Copyright (c) 2003-2004, Dean Allen &lt;dean@textism.com&gt;
All rights reserved.

Thanks to Carlo Zottmann &lt;carlo@g-blog.net&gt; for refactoring
Textile's procedural code into a class framework

Additions and fixes Copyright (c) 2006 Alex Shiels http://thresholdstate.com/
