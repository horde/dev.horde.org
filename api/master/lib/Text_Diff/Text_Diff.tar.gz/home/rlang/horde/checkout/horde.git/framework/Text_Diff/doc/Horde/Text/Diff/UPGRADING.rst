===========================
 Upgrading Horde_Text_Diff
===========================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.2.0
==================

  - Horde_Text_Diff_Renderer_Unified_Color

    This class has been added.
