======================
 Upgrading Horde_Util
======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.0.0
==================

Horde_Array::replaceRecursive() has been removed. Use array_replace_recursive()
instead.

Horde_Util::cloneObject() has been removed. Use the clone statement instead.

Horde_Util::getTempDir() has been removed. Use sys_get_temp_dir() instead.
