=====================
 Upgrading Horde_Dav
=====================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.0.0
==================

  - Horde_Dav_Client

    This class has been removed. Use the \Sabre\DAV\Client directly instead.
