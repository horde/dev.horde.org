<?php

class Horde_Kolab_FreeBusy_Stub_User
{
    public function getDomain()
    {
        return 'example.org';
    }
}