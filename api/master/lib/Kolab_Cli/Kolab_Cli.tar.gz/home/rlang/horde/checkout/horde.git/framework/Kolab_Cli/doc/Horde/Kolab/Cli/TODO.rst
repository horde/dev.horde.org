================================
 Kolab_Cli Development TODO List
================================
 
 - decent output handling (remove code duplication)

 - config file support

 - defect checking for kolab folders

 - repair functionality
