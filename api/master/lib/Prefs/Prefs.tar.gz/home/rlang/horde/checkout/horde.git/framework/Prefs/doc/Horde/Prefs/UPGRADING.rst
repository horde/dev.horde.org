=======================
 Upgrading Horde_Prefs
=======================

:Contact: dev@lists.horde.org

.. contents:: Contents
.. section-numbering::


This lists the API changes between releases of the package.


Upgrading to 2.9.0
==================

  - Horde_Prefs

    - The getScopeObject() method has been added.


Upgrading to 2.8.0
==================

  - Horde_Prefs

    - The removeAll() method has been added.
