<?php

class Foo extends Horde_Db_Migration_Base
{
    public function up()
    {
    }

    public function down()
    {
    }
}