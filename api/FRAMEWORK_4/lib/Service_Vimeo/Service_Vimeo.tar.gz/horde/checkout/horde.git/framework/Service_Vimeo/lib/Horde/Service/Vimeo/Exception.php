<?php
/**
 * Vimeo exceptions
 *
 * Copyright 2009-2012 Horde LLC (http://www.horde.org/)
 *
 * @author Michael J. Rubinsky <mrubinsk@horde.org>
 * @license  http://www.horde.org/licenses/bsd BSD
 * @category Horde
 * @package  Service_Vimeo
 */
class Horde_Service_Vimeo_Exception extends Exception
{
}