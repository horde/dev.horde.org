CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255),
    favorite_id INTEGER,
    phone VARCHAR(20),
    created VARCHAR(10),
    updated VARCHAR(10)
);
