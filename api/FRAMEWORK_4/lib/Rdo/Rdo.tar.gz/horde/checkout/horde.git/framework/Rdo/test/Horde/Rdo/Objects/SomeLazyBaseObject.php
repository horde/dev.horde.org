<?php

class Horde_Rdo_Test_Objects_SomeLazyBaseObject extends Horde_Rdo_Base
{
}
