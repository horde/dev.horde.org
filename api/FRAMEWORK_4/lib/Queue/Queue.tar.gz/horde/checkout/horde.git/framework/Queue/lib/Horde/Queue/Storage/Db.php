<?php
/**
 * Stores queue tasks in a database table.
 */
class Horde_Queue_Storage_Db extends Horde_Queue_Storage_Base
{
    protected $_db;

    public function add($task)
    {
    }

    public function getMany($num = 50)
    {
    }
}
