<?php
abstract class Horde_Queue_Storage_Base
{
}
