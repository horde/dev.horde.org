<?php
class Horde_Date_Parser_Locale_De_Ordinal extends Horde_Date_Parser_Locale_Base_Ordinal
{
    public $ordinalRegex = '/^(\d*)\.$/';
    public $ordinalDayRegex = '/^(\d*)\.$/';

}
