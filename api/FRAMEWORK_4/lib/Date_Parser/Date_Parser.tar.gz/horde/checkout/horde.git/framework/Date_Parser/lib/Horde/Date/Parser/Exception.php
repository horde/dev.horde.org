<?php
class Horde_Date_Parser_Exception extends Exception
{
}
