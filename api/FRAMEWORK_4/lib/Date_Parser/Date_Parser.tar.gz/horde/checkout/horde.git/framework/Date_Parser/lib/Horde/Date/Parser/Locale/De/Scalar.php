<?php
class Horde_Date_Parser_Locale_De_Scalar extends Horde_Date_Parser_Locale_Base_Scalar
{
}
