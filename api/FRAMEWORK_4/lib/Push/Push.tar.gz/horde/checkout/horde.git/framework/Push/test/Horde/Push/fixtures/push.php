<?php
$push['summary'] = 'PHP';
$push['body'] = 'A PHP push.';