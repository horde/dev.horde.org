<?php
class Horde_ActiveSync_Exception extends Horde_Exception_Wrapped
{
}