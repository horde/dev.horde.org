<?php
class Horde_ActiveSync_Exception_InvalidRequest extends Horde_ActiveSync_Exception
{
}