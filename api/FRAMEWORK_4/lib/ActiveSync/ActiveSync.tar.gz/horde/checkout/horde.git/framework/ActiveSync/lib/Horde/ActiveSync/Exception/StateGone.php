<?php
class Horde_ActiveSync_Exception_StateGone extends Horde_ActiveSync_Exception
{
}