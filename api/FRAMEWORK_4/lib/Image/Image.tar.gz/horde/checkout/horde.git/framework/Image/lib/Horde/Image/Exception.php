<?php
/**
 * Exception class for Horde_Image
 *
 * @author Michael J. Rubinsky <mrubinsk@horde.org>
 * @category Horde
 * @package Image
 */
class Horde_Image_Exception extends Horde_Exception_Wrapped {
}
