<?php
/**
 * Patchset constant container class.
 *
 * @package Vcs
 */
class Horde_Vcs_Patchset
{
    const MODIFIED = 0;
    const ADDED = 1;
    const DELETED = 2;
}
