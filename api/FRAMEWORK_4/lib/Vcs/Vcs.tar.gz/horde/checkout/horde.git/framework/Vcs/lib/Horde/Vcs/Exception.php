<?php
class Horde_Vcs_Exception extends Horde_Exception {}
