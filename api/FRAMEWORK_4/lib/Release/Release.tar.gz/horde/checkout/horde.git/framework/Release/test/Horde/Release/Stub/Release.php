<?php

class Horde_Release_Stub_Release extends Horde_Release
{
    public function setDirectoryName($dir)
    {
        $this->_directoryName = $dir;
    }
}