<?php

class Horde_Group_Test extends Horde_Group_Mock
{
    protected $_groups = array('mygroup' => array('name' => 'mygroup',
                                                  'users' => array('john')));
}
