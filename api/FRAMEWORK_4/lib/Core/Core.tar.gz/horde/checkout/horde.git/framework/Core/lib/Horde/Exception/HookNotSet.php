<?php
/**
 * Horde_Exception_HookNotSet is thrown when a called Horde hook does
 * not exist.
 *
 * @category Horde
 * @package  Core
 */
class Horde_Exception_HookNotSet extends Exception
{
}
