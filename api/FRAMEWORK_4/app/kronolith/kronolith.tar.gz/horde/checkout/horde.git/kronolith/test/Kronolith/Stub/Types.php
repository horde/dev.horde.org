<?php

class Content_Types_Manager
{
  public function ensureTypes()
  {
  }
}