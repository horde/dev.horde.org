<div data-role="page" data-theme="b" id="eventview">
  <div data-role="header"><h1><?php echo _("Event")?></h1></div>
  <div data-role="content" class="ui-body"></div>
</div>
    