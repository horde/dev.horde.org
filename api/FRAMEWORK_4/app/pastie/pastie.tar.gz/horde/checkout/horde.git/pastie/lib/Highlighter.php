<?php
class Pastie_Highlighter {}
