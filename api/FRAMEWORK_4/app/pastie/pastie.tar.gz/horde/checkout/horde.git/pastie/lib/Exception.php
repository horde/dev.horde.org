<?php
class Pastie_Exception extends Horde_Exception_Wrapped
{
}
