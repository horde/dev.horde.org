<?php
class Pastie_Api extends Horde_Registry_Api
{
}
