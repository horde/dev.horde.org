<?php

require dirname(__FILE__) . '/forums.php';
