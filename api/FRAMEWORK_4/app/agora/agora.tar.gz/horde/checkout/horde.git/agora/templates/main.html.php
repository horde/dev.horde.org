<?php echo $this->menu; ?>
<?php echo $this->notify; ?>
<?php echo $this->main; ?>
