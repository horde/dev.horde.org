<?php
/**
 * @package Horde_Form
 */
class Whups_Form_Type_whupsemail extends Horde_Form_Type_email {}