<div id="notification" data-role="dialog">
  <div data-role="header">
    <h1><?php echo _("Notice")?></h1>
  </div>
  <div data-role="content" class="ui-body">
    <ul id="horde-notification" data-role="listview">
    </ul>
  </div>
</div>