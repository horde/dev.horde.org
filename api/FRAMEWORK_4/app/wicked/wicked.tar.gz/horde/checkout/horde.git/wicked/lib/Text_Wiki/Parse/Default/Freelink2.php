<?php

require_once 'Text/Wiki/Parse/Default/Freelink.php';

/**
 * Placeholder class as a complement to the Freelink2 renderer.
 *
 * @package Wicked
 */
class Text_Wiki_Parse_Freelink2 extends Text_Wiki_Parse_Freelink { }
