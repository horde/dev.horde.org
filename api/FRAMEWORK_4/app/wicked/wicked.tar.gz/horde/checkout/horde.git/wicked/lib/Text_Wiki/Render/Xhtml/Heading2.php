<?php
/**
 * @package Wicked
 */
class Text_Wiki_Render_Xhtml_Heading2 extends Text_Wiki_Render_Xhtml_Heading
{
}
