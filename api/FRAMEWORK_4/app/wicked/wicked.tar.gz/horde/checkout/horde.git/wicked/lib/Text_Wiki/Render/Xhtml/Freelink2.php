<?php

require_once dirname(__FILE__) . '/Wikilink2.php';

class Text_Wiki_Render_Xhtml_Freelink2 extends Text_Wiki_Render_Xhtml_Wikilink2 {}
