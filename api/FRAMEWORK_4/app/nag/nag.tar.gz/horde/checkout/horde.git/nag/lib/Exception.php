<?php
/**
 * Base exception class for Nag.
 *
 * Copyright 2009-2012 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.horde.org/licenses/gpl.
 *
 * @package Nag
 */
class Nag_Exception extends Horde_Exception_Wrapped
{
}
