<table width="100%" cellspacing="0">
 <tr>
  <td>
   <?php echo $this->main; ?>
  </td>
 </tr>
</table>
