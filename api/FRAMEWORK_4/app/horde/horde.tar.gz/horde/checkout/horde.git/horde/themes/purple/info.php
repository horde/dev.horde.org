<?php
$theme_name = _("Purple Horde");
