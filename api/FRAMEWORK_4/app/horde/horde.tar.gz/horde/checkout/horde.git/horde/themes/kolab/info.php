<?php
/**
 * Kolab theme by Stuart Binge <s.binge@codefusion.co.za>
 * Derived from the 'Light Blue' theme.
 */

$theme_name = _("Kolab");
