<?php
$theme_name = _("Light Blue");
