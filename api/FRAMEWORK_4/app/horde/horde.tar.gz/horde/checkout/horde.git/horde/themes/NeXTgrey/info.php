<?php
$theme_name = _("NeXT");
