ALTER TABLE horde_signups DROP COLUMN signup_email;
