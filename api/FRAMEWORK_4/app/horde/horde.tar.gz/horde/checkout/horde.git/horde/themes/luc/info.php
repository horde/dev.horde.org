<?php
$theme_name = _("Loyola");
