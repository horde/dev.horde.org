<?php
$theme_name = _("Barbie");
