<?php
/**
 * Hordevetica Theme
 *
 * Silk icons are from Mark James
 * (http://www.famfamfam.com/lab/icons/silk/), used under a Creative
 * Commons Attribution 2.5 License. [
 * http://creativecommons.org/licenses/by/2.5/ ]. "This means you may
 * use it for any purpose, and make any changes you like.  All I ask
 * is that you include a link back to this page in your credits."
 *
 * Flag icons are from http://www.famfamfam.com/ and are in the public
 * domain.
 *
 * Based on Silver Surfer theme by Daniel Dembach http://blog.dembachco.de/.
 *
 * @author Chuck Hagenbuch <chuck@horde.org>
 */

$theme_name = ("Hordevetica");
