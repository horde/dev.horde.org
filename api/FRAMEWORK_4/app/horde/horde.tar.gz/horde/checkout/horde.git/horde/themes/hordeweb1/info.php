<?php
$theme_name = _("Old Horde Website");
