<?php
$theme_name = _("Horde Website");
