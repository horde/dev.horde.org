<?php

$theme_name = _("Hi-Contrast");
