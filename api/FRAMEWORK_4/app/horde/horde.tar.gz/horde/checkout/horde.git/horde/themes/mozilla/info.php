<?php
$theme_name = _("Mozilla");
