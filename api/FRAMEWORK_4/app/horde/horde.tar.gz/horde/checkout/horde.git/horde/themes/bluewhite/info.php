<?php
$theme_name = _("Blue and White");
