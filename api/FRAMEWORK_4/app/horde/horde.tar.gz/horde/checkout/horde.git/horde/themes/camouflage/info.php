<?php
$theme_name = _("Camouflage");
