<?php
$theme_name = _("Ideas");
