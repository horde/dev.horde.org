<?php
$theme_name = _("Green");
