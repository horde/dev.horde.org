<?php
/**
 * @author Joost De Cock <joost@decock.org>
 */

$theme_name = _("Azur");
