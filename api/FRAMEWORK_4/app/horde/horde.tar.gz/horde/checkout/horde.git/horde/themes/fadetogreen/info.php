<?php
/**
 * This theme was made by Roel Gloudemans <roel@gloudemans.info>
 *
 * This theme is the basis for the website at http://www.gloudemans.info,
 * http://www.clubsmc.nl and others
 */

$theme_name = _("Fade to Green");
