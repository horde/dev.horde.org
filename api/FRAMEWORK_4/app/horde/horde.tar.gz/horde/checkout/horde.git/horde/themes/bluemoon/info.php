<?php
$theme_name = _("Blue Moon");
