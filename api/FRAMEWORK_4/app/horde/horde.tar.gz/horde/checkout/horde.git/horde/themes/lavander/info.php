<?php
$theme_name = _("Lavender");
