<?php
$theme_name = _("Simplex");
