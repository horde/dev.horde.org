<?php
/**
 * Theme by: Eric Jon Rostetter <eric.rostetter@physics.utexas.edu>
 * Please contact the theme's author for any missing style.
 */

$theme_name = _("Burnt Orange");
