<?php
/**
 * This theme as been written by Aide Florent <faide@alphacent.com> and
 * M�lanie Gareau <melanie.gareau@ville-gennevilliers.fr>
 *
 * The theme idea was to incorporate smoothly in the intranet.
 * This theme is published under the same license as the horde package.
 *
 * The name comes from the city of Gennevilliers in France
 */

$theme_name = _("Teal");
