<?php
require('circulartext.php');


$pdf = PDF_CircularText::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_CircularText');
$pdf->AddPage();
$pdf->SetFont('Arial','',32);

$text='Circular Text';
$pdf->CircularText(105, 50, 30, $text, 'top');
$pdf->CircularText(105, 50, 30, $text, 'bottom');

$pdf->Output('',true);
?>