<?php
define('FPDF_FONTPATH','font/');
require('i25.php');


$pdf = PDF_i25::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_i25');
$pdf->AddPage();
$pdf->i25(90,40,'12345678');
$pdf->Output('',true);
?>
