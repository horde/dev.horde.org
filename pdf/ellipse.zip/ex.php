<?php
require('ellipse.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->Ellipse(100,50,30,20);
$pdf->SetFillColor('rgb',255/255,255/255,0/255);
$pdf->Circle(110,47,7,'F');
$pdf->Output('',true);

?>