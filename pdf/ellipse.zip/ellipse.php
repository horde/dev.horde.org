<?php
/**
 * Based on the Circles and Ellipses script by Olivier Plathey (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre
 */
require('File/PDF.php');


class PDF extends File_PDF
{
function Circle($x,$y,$r,$style='')
{
	$this->Ellipse($x,$y,$r,$r,$style);
}

function Ellipse($x,$y,$rx,$ry,$style='D')
{
	if($style=='F')
		$op='f';
	elseif($style=='FD' or $style=='DF')
		$op='B';
	else
		$op='S';
	$lx=4/3*(M_SQRT2-1)*$rx;
	$ly=4/3*(M_SQRT2-1)*$ry;
	$k=$this->_scale;
	$h=$this->fh;
	$this->_out(sprintf('%.2f %.2f m %.2f %.2f %.2f %.2f %.2f %.2f c',
		($x+$rx)*$k,($h-$y)*$k,
		($x+$rx)*$k,($h-($y-$ly))*$k,
		($x+$lx)*$k,($h-($y-$ry))*$k,
		$x*$k,($h-($y-$ry))*$k));
	$this->_out(sprintf('%.2f %.2f %.2f %.2f %.2f %.2f c',
		($x-$lx)*$k,($h-($y-$ry))*$k,
		($x-$rx)*$k,($h-($y-$ly))*$k,
		($x-$rx)*$k,($h-$y)*$k));
	$this->_out(sprintf('%.2f %.2f %.2f %.2f %.2f %.2f c',
		($x-$rx)*$k,($h-($y+$ly))*$k,
		($x-$lx)*$k,($h-($y+$ry))*$k,
		$x*$k,($h-($y+$ry))*$k));
	$this->_out(sprintf('%.2f %.2f %.2f %.2f %.2f %.2f c %s',
		($x+$lx)*$k,($h-($y+$ry))*$k,
		($x+$rx)*$k,($h-($y+$ly))*$k,
		($x+$rx)*$k,($h-$y)*$k,
		$op));
}
}


?>
