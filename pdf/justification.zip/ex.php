<?php
require('justification.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',9);
$pdf->Cell(85,4,"EXAMPLE OF FUNCTION USAGE",1,1,'C');
$pdf->Write(4,"\nSource: http://www.swg-fr.com\n\n");
$f=fopen('ex.txt','r');
$text=fread($f,filesize('ex.txt'));
fclose($f);
$pdf->Justify($text,85,4);
$pdf->Output('',true);
?>