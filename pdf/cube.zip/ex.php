<?php

require('cube.php');

$pdf = PDF_Cube::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Cube');
$pdf->AddPage();
$pdf->Cube($a,$b,$c,$scale,$alfax,$alfay,$alfaz);
$pdf->Output('',true);
?>