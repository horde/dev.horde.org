<?php
/**
 * Based on the Watermark script by Ivan (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre
 */
define('FPDF_FONTPATH','font/');
require('..\rotation\rotation.php');

class PDF extends PDF_Rotate
{
function Header()
{
	//Put watermark
	$this->SetFont('Arial','B',50);
	$this->SetTextColor('rgb',255/255,192/255,203/203);
	$this->RotatedText(30,190,'W a t e r m a r k   d e m o',45);
}

function RotatedText($x,$y,$txt,$angle)
{
	//Text rotated around its origin
	$this->Rotate($angle,$x,$y);
	$this->Text($x,$y,$txt);
	$this->Rotate(0);
}
}


?>
