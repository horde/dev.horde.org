<?php
require('watermark.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);
$txt='FPDF is a PHP class which allows to generate PDF files with straight PHP, that is to say '.
	'without using the PDFlib library. The advantage is that the latter requires a fee for a '.
	'commercial usage. F from FPDF stands for Free: you may use it for any kind of usage and '.
	'modify it to suit your needs.';
for($i=0;$i<25;$i++)
	$pdf->Write(5,$txt);
$pdf->Output('',true);
?>