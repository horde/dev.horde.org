<?php
define('FPDF_FONTPATH','font/');
require('htmlcolor.php');


$pdf = PDF_HTMLColor::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_HTMLColor');
$pdf->AddPage();
$pdf->SetDrawColor('blue');
$pdf->SetFillColor('#EE7070');
$pdf->SetTextColor('yellow');
$pdf->SetLineWidth(1);
$pdf->SetFont('Arial','',16);
$pdf->SetXY(80,40);
$pdf->Cell(50,20,'HTML Colors',1,0,'C',1);
$pdf->Output('',true);
?>
