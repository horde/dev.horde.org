<?php
require('barcode.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->EAN13(80,40,'123456789012');
$pdf->Output('',true);
?>
