<?php
/**
 * Based on the TextBox script by Darren Gates & Adrian Tufa (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */   
define('FPDF_FONTPATH','font/');
require('textbox.php');

$pdf =  PDF::factory(array('orientation' => 'P',
                           				'unit' => 'mm',
                            			'format' => 'A4'),
                      					'PDF');
$pdf->AddPage();
$pdf->SetFont('Arial','',15);
$pdf->SetX(70);
$pdf->drawTextBox('This sentence is centered in the middle of the box.', 50, 50, 'C', 'M');
$pdf->Output('',true);
?>
