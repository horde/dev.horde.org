<?php
/**
 * Based on the Bookmark script by Olivier Plathey (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */   
define('FPDF_FONTPATH','font/');
require('bookmark.php');
$pdf = PDF_Bookmark::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Bookmark');


//$pdf=new PDF_Bookmark();
$pdf->Open();
$pdf->SetFont('Arial','',15);
//Page 1
$pdf->AddPage();
$pdf->Bookmark('Page 1');
$pdf->Bookmark('Paragraph 1',1,-1);
$pdf->Cell(0,6,'Paragraph 1');
$pdf->newLine(50);
$pdf->Bookmark('Paragraph 2',1,-1);
$pdf->Cell(0,6,'Paragraph 2');
//Page 2
$pdf->AddPage();
$pdf->Bookmark('Page 2');
$pdf->Bookmark('Paragraph 3',1,-1);
$pdf->Cell(0,6,'Paragraph 3');
//$pdf->save('Bookmark.pdf');;
$pdf->Output('',true);
?>
