<?php
require('fontdump.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->DumpFont('Arial');
$pdf->DumpFont('Symbol');
$pdf->DumpFont('ZapfDingbats');
$pdf->Output('',true);
?>