<?php
/**
 * Based on the Sector script by Maxime Delorme (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
require('sector.php');

$pdf =  PDF_Sector::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Sector');
$pdf->Open();
$pdf->AddPage();
$xc=105;
$yc=55;
$r=40;
$pdf->SetFillColor('rgb',120/255,120/255,255/255);
$pdf->Sector($xc,$yc,$r,20,120);
$pdf->SetFillColor('rgb',120/255,255/255,120/255);
$pdf->Sector($xc,$yc,$r,120,250);
$pdf->SetFillColor('rgb',255/255,120/255,120/255);
$pdf->Sector($xc,$yc,$r,250,20);
$pdf->Output('',true);
?>
