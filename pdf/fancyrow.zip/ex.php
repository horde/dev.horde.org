<?php
define('FPDF_FONTPATH','font/');
ini_set("display_errors",0);
require 'fancyrow.php';


$pdf =  PDF_FancyRow::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_FancyRow');
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);
$pdf->Write(12,'Please fill in your name, company and email below:');
$pdf->newLine(20);
$widths = array(5, 40, 5, 40, 5, 40);
$border = array('', 'LBR', '', 'LBR', '', 'LBR');
$caption = array('','Name', '', 'Company','', 'Email');
$align = array('', 'C', '', 'C', '', 'C');
$style = array('', 'I', '', 'I', '', 'I');
$empty = array('','','','','','');
$pdf->SetWidths($widths);
$pdf->FancyRow($empty, $border);
$pdf->FancyRow($caption, array(), $align, $style);
$pdf->Output('',true);
?>
