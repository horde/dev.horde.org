<?php
/**
 * Based on the Write HTML script by Aramis (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
define('FPDF_FONTPATH','font/');
require('WriteHTML.php');

$pdf =  PDF_HTML::factory(array('orientation' => 'P',
                           				'unit' => 'mm',
                            			'format' => 'A4'),
                      					'PDF_HTML');
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial');
$pdf->WriteHTML('You can<BR><P ALIGN="center">center a line</P>and add a horizontal rule:<BR><HR>');
$pdf->Output('',true);
?>
