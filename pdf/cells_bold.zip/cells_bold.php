<?php
/**
 * Based on the Tags for cells and bold script by Marcio Sfalsin (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre
 */
define('FPDF_FONTPATH','font/');
require('File/PDF.php');

class PDF extends File_PDF
{

function WriteText($text)
{
	$intPosIni = 0;
	$intPosFim = 0;
	if (strpos($text,'<')!==false and strpos($text,'[')!==false)
	{
		if (strpos($text,'<')<strpos($text,'['))
		{
			$this->Write(5,substr($text,0,strpos($text,'<')));
			$intPosIni = strpos($text,'<');
			$intPosFim = strpos($text,'>');
			$this->SetFont('','B');
			$this->Write(5,substr($text,$intPosIni+1,$intPosFim-$intPosIni-1));
			$this->SetFont('','');
			$this->WriteText(substr($text,$intPosFim+1,strlen($text)));
		}
		else
		{
			$this->Write(5,substr($text,0,strpos($text,'[')));
			$intPosIni = strpos($text,'[');
			$intPosFim = strpos($text,']');
			$w=$this->GetStringWidth('a',false)*($intPosFim-$intPosIni-1);
			$this->Cell($w,$this->_font_size+0.75,substr($text,$intPosIni+1,$intPosFim-$intPosIni-1),1,0,'');
			$this->WriteText(substr($text,$intPosFim+1,strlen($text)));
		}
	}
	else
	{
		if (strpos($text,'<')!==false)
		{
			$this->Write(5,substr($text,0,strpos($text,'<')));
			$intPosIni = strpos($text,'<');
			$intPosFim = strpos($text,'>');
			$this->SetFont('','B');
			$this->WriteText(substr($text,$intPosIni+1,$intPosFim-$intPosIni-1));
			$this->SetFont('','');
			$this->WriteText(substr($text,$intPosFim+1,strlen($text)));
		}
		elseif (strpos($text,'[')!==false)
		{
			$this->Write(5,substr($text,0,strpos($text,'[')));
			$intPosIni = strpos($text,'[');
			$intPosFim = strpos($text,']');
			$w=$this->GetStringWidth('a',false)*($intPosFim-$intPosIni-1);
			$this->Cell($w,$this->_font_size+0.75,substr($text,$intPosIni+1,$intPosFim-$intPosIni-1),1,0,'');
			$this->WriteText(substr($text,$intPosFim+1,strlen($text)));
		}
		else
		{
			$this->Write(5,$text);
		}

	}
}

}


?>
