<?php
require('morepagestable.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'pt',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',12);
$pdf->multiCell(0,20,'Example to build Tables over more than one Page.');
// set the tablewidths like this or write an extra function
$pdf->tablewidths = array(90,90,90,90,90,90);

srand(microtime()*1000000);
for($i=0; $i < 4; $i++) {
	$datas[] = array(GenerateSentence(),GenerateSentence(),GenerateSentence(),GenerateSentence(),GenerateSentence(),GenerateSentence());
}

$pdf->setFont('Arial','',6);
$pdf->morepagestable($datas);
$pdf->Output('',true);
?>