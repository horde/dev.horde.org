<?php
/**
 * Based on the 	Table with multi-page columns script by Jan Slabon (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre
 */
define('FPDF_FONTPATH','font/');
require('File/PDF.php');;

class PDF extends File_PDF {

var $tablewidths;
var $footerset;



function _beginpage($orientation) {
	$this->_page++;
	if(!$this->_pages[$this->_page]) // solved the problem of overwriting a page, if it already exists
		$this->_pages[$this->_page]='';
	$this->_state=2;
	$this->x=$this->_left_margin;
	$this->y=$this->_top_margin;
	$this->_last_height=0;
	$this->FontFamily='';
	//Page orientation
	if(!$orientation)
		$orientation=$this->_default_orientation;
	else
	{
		$orientation=strtoupper($orientation{0});
		if($orientation!=$this->_default_orientation)
			$this->_orientation_changes[$this->_page]=true;
	}
	if($orientation!=$this->_current_orientation)
	{
		//Change orientation
		if($orientation=='P')
		{
			$this->wPt=$this->fwPt;
			$this->hPt=$this->fhPt;
			$this->w=$this->fw;
			$this->h=$this->fh;
		}
		else
		{
			$this->wPt=$this->fhPt;
			$this->hPt=$this->fwPt;
			$this->w=$this->fh;
			$this->h=$this->fw;
		}
		$this->_page_break_trigger=$this->h-$this->_break_margin;
		$this->_current_orientation=$orientation;
	}
}

function Footer() {
	// Check if Footer for this page already exists (do the same for Header())
	if(!$this->footerset[$this->_page]) {
		$this->SetY(-15);
		//Page number
		$this->Cell(0,10,'Page '.$this->getPageNo().'/{nb}',0,0,'C');
		// set footerset
		$this->footerset[$this->_page] = 1;
	}
}

function morepagestable($datas,$lineheight=8) {
	// some things to set and 'remember'
	$l = $this->_left_margin;
	$startheight = $h = $this->getY();
	$startpage = $currpage = $this->_page;

	// calculate the whole width
	foreach($this->tablewidths AS $width) {
		$fullwidth += $width;
	}

	// Now let's start to write the table
	foreach($datas AS $row => $data) {
		$this->_page = $currpage;
		// write the horizontal borders
		$this->line($l,$h,$fullwidth+$l,$h);
		// write the content and remember the height of the highest col
		foreach($data AS $col => $txt) {
			$this->_page = $currpage;
			$this->setXY($l,$h);
			$this->multiCell($this->tablewidths[$col],$lineheight,$txt);
			$l += $this->tablewidths[$col];

			if($tmpheight[$row.'-'.$this->_page] < $this->getY()) {
				$tmpheight[$row.'-'.$this->_page] = $this->getY();
			}
			if($this->_page > $maxpage)
				$maxpage = $this->_page;
		}

		// get the height we were in the last used page
		$h = $tmpheight[$row.'-'.$maxpage];
		// set the "pointer" to the left margin
		$l = $this->_left_margin;
		// set the $currpage to the last page
		$currpage = $maxpage;
	}
	// draw the borders
	// we start adding a horizontal line on the last page
	$this->_page = $maxpage;
	$this->line($l,$h,$fullwidth+$l,$h);
	// now we start at the top of the document and walk down
	for($i = $startpage; $i <= $maxpage; $i++) {
		$this->_page = $i;
		$l = $this->_left_margin;
		$t  = ($i == $startpage) ? $startheight : $this->_top_margin;
		$lh = ($i == $maxpage)   ? $h : $this->h-$this->_break_margin;
		$this->line($l,$t,$l,$lh);
		foreach($this->tablewidths AS $width) {
			$l += $width;
			$this->line($l,$t,$l,$lh);
		}
	}
	// set it to the last page, if not it'll cause some problems
	$this->_page = $maxpage;
}

}

function GenerateWord()
{
	//Get a random word
	$nb=rand(3,10);
	$w='';
	for($i=1;$i<=$nb;$i++)
		$w.=chr(rand(ord('a'),ord('z')));
	return $w;
}

function GenerateSentence($words="500")
{
	//Get a random sentence
	$nb=rand(20,$words);
	$s='';
	for($i=1;$i<=$nb;$i++)
		$s.=GenerateWord().' ';
	return substr($s,0,-1);
}



?>
