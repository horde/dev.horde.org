<?php
/**
 * Based on the Star script by Luciano Salvino (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */
require('File/PDF.php');

class PDF_Star extends File_PDF
{

function Star($x,$y,$rin,$rout,$points,$style='D')
{
	if($style=='F')
		$op='f';
	elseif($style=='FD' or $style=='DF')
		$op='B';
	else
		$op='S';
	$cx = array($points*2);
	$cy = array($points*2);
	$dth = (pi()/$points);
	$th = 0;
	$k=$this->_scale;
	$h=$this->h;
	$points_string = '';
	for($i=0;$i<($points*2)+1;$i++)
	{
		$th = $th+$dth;
		$cx[$i] = $x + ((($i%2==0)?$rin:$rout) * cos($th));
		$cy[$i] = $y + ((($i%2==0)?$rin:$rout) * sin($th));
		$points_string .= sprintf('%.2f %.2f', $cx[$i]*$k, ($h-$cy[$i])*$k);
		if($i==0)
			$points_string .= ' m ';
		else
			$points_string .= ' l ';
	}
	$this->_out($points_string . $op);
}

}
?>
