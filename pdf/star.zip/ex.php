<?php
require('star.php');


$pdf = PDF_Star::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Star');
$pdf->AddPage();
$pdf->SetDrawColor('rgb',0,0,0);
$pdf->SetFillColor('rgb',255/255,0,0);
$pdf->SetLineWidth(0.5);
$pdf->Star(100,50,40,30,36,'DF');
$pdf->Output('',true);
?>
