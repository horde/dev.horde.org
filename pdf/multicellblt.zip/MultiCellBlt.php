<?php
/**
 * Based on the MultiCell with bullet script by Patrick Benny (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
define('FPDF_FONTPATH','font/');
require('File/PDF.php');

class PDF extends File_PDF
{

	//MultiCell with bullet
	function MultiCellBlt($w,$h,$blt,$txt,$border=0,$align='J',$fill=0)
	{
		//Get bullet width including margins
		$blt_width = $this->GetStringWidth($blt)+$this->_cell_margin*2;

		//Save x
		$bak_x = $this->x;

		//Output bullet
		$this->Cell($blt_width,$h,$blt,0,'',$fill);
		//Output text
		$this->MultiCell($w-$blt_width,$h,$txt,$border,$align,$fill);

		//Restore x
		$this->x = $bak_x;
	}

}


?>
