<?php
/**
 * Based on the Polygons script by Andrew Meier (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
require('File/PDF.php');

class PDF_Polygon extends File_PDF
{

function Polygon($points, $style='D')
{
	//Draw a polygon
	if($style=='F')
		$op='f';
	elseif($style=='FD' or $style=='DF')
		$op='b';
	else
		$op='s';

	$h = $this->h;
	$k = $this->_scale;

	$points_string = '';
	for($i=0; $i<count($points); $i+=2){
		$points_string .= sprintf('%.2f %.2f', $points[$i]*$k, ($h-$points[$i+1])*$k);
		if($i==0)
			$points_string .= ' m ';
		else
			$points_string .= ' l ';
	}
	$this->_out($points_string . $op);
}

}
?>
