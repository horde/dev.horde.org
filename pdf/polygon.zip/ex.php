<?php
require('polygon.php');


$pdf = PDF_Polygon::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Polygon');
$pdf->AddPage();
$pdf->SetDrawColor('rgb',255/255,0,0);
$pdf->SetFillColor('rgb',0,0,255/255);
$pdf->SetLineWidth(4);
$pdf->Polygon(array(50,115,150,115,100,20),'FD');
$pdf->Output('',true);
?>
