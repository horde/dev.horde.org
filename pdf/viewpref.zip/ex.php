<?php
require('viewpref.php');

$pdf =  PDF::factory(array('orientation' => 'P',
                           				'unit' => 'mm',
                            			'format' => 'A4'),
                      					'PDF');
$pdf->SetDisplayMode('fullpage');
$pdf->DisplayPreferences('HideMenubar,HideToolbar,HideWindowUI');
$pdf->AddPage();
$pdf->SetFont('Arial','',16);
$pdf->Write(6,'Only the document should appear, no interface element.');
$pdf->Output('',true);
?>