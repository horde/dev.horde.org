<?php
/**
 * Based on the Write HTML tables script by Rick van Buuren (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */   
define('FPDF_FONTPATH','font/');
require('html_table.php');

$pdf =  PDF::factory(array('orientation' => 'P',
                           				'unit' => 'mm',
                            			'format' => 'A4'),
                      					'PDF');
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

$html='<table border="1">
<tr>
<td width="200" height="30">cell 1</td><td width="200" height="30" bgcolor="#D0D0FF">cell 2</td>
</tr>
<tr>
<td width="200" height="30">cell 3</td><td width="200" height="30">cell 4</td>
</tr>
</table>';

$pdf->WriteHTML($html);
$pdf->Output('',true);
?>
