<?php
/**
 * Based on the Small caps script by Constantin Teleman (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */                                                                   

require('File/PDF.php');

class PDF_SmallCaps extends File_PDF
{

/**
* Create the Small Caps effect in a Cell
* @author constantin teleman
*/
function CellSmallCaps($w,$h=0,$txt='',$border=0,$ln=0,$align='',$fill=0,$link='')
{
	//Output a cell
	$k=$this->_scale;
	if($this->y+$h>$this->_page_break_trigger && !$this->InFooter && $this->AcceptPageBreak())
	{
		//Automatic page break
		$x=$this->x;
		$ws=$this->_word_spacing;
		if($ws>0)
		{
			$this->_word_spacing=0;
			$this->_out('0 Tw');
		}
		$this->AddPage($this->_current_orientation);
		$this->x=$x;
		if($ws>0)
		{
			$this->_word_spacing=$ws;
			$this->_out(sprintf('%.3f Tw',$ws*$k));
		}
	}
	if($w==0)
		$w=$this->w-$this->_right_margin-$this->x;
	$s='';
	if($fill==1 || $border==1)
	{
		if($fill==1)
			$op=($border==1) ? 'B' : 'f';
		else
			$op='S';
		$s=sprintf('%.2f %.2f %.2f %.2f re %s ',$this->x*$k,($this->h-$this->y)*$k,$w*$k,-$h*$k,$op);
	}
	if(is_string($border))
	{
		$x=$this->x;
		$y=$this->y;
		if(strpos($border,'L')!==false)
			$s.=sprintf('%.2f %.2f m %.2f %.2f l S ',$x*$k,($this->h-$y)*$k,$x*$k,($this->h-($y+$h))*$k);
		if(strpos($border,'T')!==false)
			$s.=sprintf('%.2f %.2f m %.2f %.2f l S ',$x*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-$y)*$k);
		if(strpos($border,'R')!==false)
			$s.=sprintf('%.2f %.2f m %.2f %.2f l S ',($x+$w)*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
		if(strpos($border,'B')!==false)
			$s.=sprintf('%.2f %.2f m %.2f %.2f l S ',$x*$k,($this->h-($y+$h))*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
	}
	if($txt!=='')
	{
		//part for calculating position of text
		if($align=='R') //right align
			$dx=$w-$this->_cell_margin-$this->GetStringWidth($txt);
		elseif($align=='C') //center align
			$dx=($w-$this->GetStringWidth($txt))/2;
		else  //for left align
			$dx=$this->_cell_margin;
			
			
		if($this->_color_flag)
			$s.='q '.$this->TextColor.' ';
		
		$txt2=str_replace(')','\\)',str_replace('(','\\(',str_replace('\\','\\\\',$txt)));
		//first letter in the word
		//$txtFirst = strtoupper(substr($txt2,0,1));
		//$txtRest = strtoupper(substr($txt2,1));
		$firstDx = $dx;
		for ($i=0; $i<strlen($txt2); $i++) {
			$letter = substr($txt2,$i,1);
			$upper = strpos("ABCDEFGHIJKLMNOPQRSTUVWXZ0123456789`!@#$%^&*()_=+|'\";:{}[]?,.<>",$letter);
			if ($upper === false) { //case the letter is lowercase
				if($i==0){ //for the first char
					$s.=sprintf(' BT /F%d %.2f Tf',$this->CurrentFont['i'],$this->_font_size_pt*0.8);
					$s.=sprintf(' %.2f %.2f Td (%s) Tj',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->_font_size))*$k,strtoupper($letter));
					$s.=sprintf(' /F%d %.2f Tf ET',$this->CurrentFont['i'],$this->_font_size_pt);
				} else {  // if there is no first char
					$s.=sprintf(' BT /F%d %.2f Tf',$this->CurrentFont['i'],$this->_font_size_pt*0.8);
					$dx+=($this->GetStringWidth(substr($txt2,$i-1,1)))*1.02;
					$s.=sprintf(' %.2f %.2f Td (%s) Tj',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->_font_size))*$k,strtoupper($letter));
					$s.=sprintf(' /F%d %.2f Tf ET',$this->CurrentFont['i'],$this->_font_size_pt);
				}
			} else { //case the letter is uppercase
				if($i == 0){ //for the first char
					$s.=sprintf(' BT %.2f %.2f Td (%s) Tj ET',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->_font_size))*$k,$letter);
				} else {  // if there is no first char
					$dx+=($this->GetStringWidth(substr($txt2,$i-1,1)))*1.02;
					$s.=sprintf(' BT %.2f %.2f Td (%s) Tj ET',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->_font_size))*$k,$letter);
				}
			}
		}
		
		if($this->underline)
			$s.=' '.$this->_dounderline($this->x+$firstDx,$this->y+.5*$h+.3*$this->_font_size,$txt);
		if($this->ColorFlag)
			$s.=' Q';
		if($link)
			$this->Link($this->x+$firstDx,$this->y+.5*$h-.5*$this->_font_size,$this->GetStringWidth($txt),$this->_font_size,$link);
	}
	if($s)
		$this->_out($s);
	$this->lasth=$h;
	if($ln>0)
	{
		//Go to next line
		$this->y+=$h;
		if($ln==1)
			$this->x=$this->_left_margin;
	}
	else
		$this->x+=$w;
}

/**
* Create the Small Caps effect in a MultiCell
* @author constantin teleman
*/
function MultiCellSmallCaps($w,$h,$txt,$border=0,$align='',$fill=0)
{
	//Output text with automatic or explicit line breaks
	$cw=&$this->CurrentFont['cw'];
	if($w==0)
		$w=$this->w-$this->_right_margin-$this->x;
	$wmax=($w-2*$this->_cell_margin)*1000/$this->_font_size;
	$s=str_replace("\r",'',$txt);
	$nb=strlen($s);
	if($nb>0 && $s[$nb-1]=="\n")
		$nb--;
	$b=0;
	if($border)
	{
		if($border==1)
		{
			$border='LTRB';
			$b='LRT';
			$b2='LR';
		}
		else
		{
			$b2='';
			if(strpos($border,'L')!==false)
				$b2.='L';
			if(strpos($border,'R')!==false)
				$b2.='R';
			$b=(strpos($border,'T')!==false) ? $b2.'T' : $b2;
		}
	}
	$sep=-1;
	$i=0;
	$j=0;
	$l=0;
	$ns=0;
	$nl=1;
	while($i<$nb)
	{
		//Get next character
		$c=$s{$i};
		if($c=="\n")
		{
			//Explicit line break
			if($this->_word_spacing>0)
			{
				$this->_word_spacing=0;
				$this->_out('0 Tw');
			}
			$this->CellSmallCaps($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
			$i++;
			$sep=-1;
			$j=$i;
			$l=0;
			$ns=0;
			$nl++;
			if($border && $nl==2)
				$b=$b2;
			continue;
		}
		if($c==' ')
		{
			$sep=$i;
			$ls=$l;
			$ns++;
		}
		$l+=$cw[$c];
		if($l>$wmax)
		{
			//Automatic line break
			if($sep==-1)
			{
				if($i==$j)
					$i++;
				if($this->_word_spacing>0)
				{
					$this->_word_spacing=0;
					$this->_out('0 Tw');
				}
				$this->CellSmallCaps($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
			}
			else
			{
				if($align=='J')
				{
					$this->_word_spacing=($ns>1) ? ($wmax-$ls)/1000*$this->_font_size/($ns-1) : 0;
					$this->_out(sprintf('%.3f Tw',$this->_word_spacing*$this->_scale));
				}
				$this->CellSmallCaps($w,$h,substr($s,$j,$sep-$j),$b,2,$align,$fill);
				$i=$sep+1;
			}
			$sep=-1;
			$j=$i;
			$l=0;
			$ns=0;
			$nl++;
			if($border && $nl==2)
				$b=$b2;
		}
		else
			$i++;
	}
	//Last chunk
	if($this->_word_spacing>0)
	{
		$this->_word_spacing=0;
		$this->_out('0 Tw');
	}
	if($border && strpos($border,'B')!==false)
		$b.='B';
	$this->CellSmallCaps($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
	$this->x=$this->_left_margin;
}

}

?>
