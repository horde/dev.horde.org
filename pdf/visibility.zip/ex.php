<?php
/**
 * Based on the Visibility script by Olivier Plathey (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */   
require('visibility.php');


$pdf =  PDF_Visibility::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Visibility');


$pdf->AddPage();
$pdf->SetFont('Arial','',14);
$pdf->SetVisibility('screen');
$pdf->Write(6,"This line is for display.\n");
$pdf->SetVisibility('print');
$pdf->Write(6,"This line is for printout.\n");
$pdf->SetVisibility('all');
$pdf->Output('',true);

?>
