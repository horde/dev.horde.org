<?php
define('FPDF_FONTPATH','font/');
require('code39.php');


$pdf = PDF_Code39::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Code39');
$pdf->AddPage();
$pdf->Code39(60, 30, 'Code 39');
$pdf->Output('',true);
?>
