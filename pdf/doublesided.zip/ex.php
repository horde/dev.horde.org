<?php
require('doublesided.php');

class PDF extends DoubleSided_PDF
{
	function Header()
	{
		if ( $this->getPageNo() % 2 == 0 ) {
			$this->Cell(30,0,$this->getPageNo(),0,0,'L');
			$this->Cell(0,0,'This chapter has a title',0,0,'R');
		}
		else {
			$this->Cell(160,0,'Topic of this chapter',0,0,'L');
			$this->Cell(0,0,$this->getPageNo(),0,2,'R');
		}
		//Line break
		$this->SetY(20);
		$this->SetLineWidth(0.01);
		$this->Line($this->_left_margin, 18, 210 - $this->_right_margin, 18);
		$this->newLine(15);
	}

	function Footer()
	{
		//Position at 1.5 cm from bottom
		$this->SetLineWidth(0.01);
		$this->Line($this->_left_margin, 281.2, 210 - $this->_right_margin, 281.2);
		$this->SetY(-10);
		//Page number
		$this->Cell(0,3,'Page '.$this->getPageNo().'/{nb}',0,0,'C');
	}
}


$pdf = PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->setcompression(false);                      
$pdf->AliasNbPages();
$pdf->SetDoubleSided(20,10);
$pdf->SetFont('Arial','',12);
$pdf->AddPage();
for ($i=0; $i < 60; $i++ )
	$pdf->MultiCell(0, 10, str_repeat('a lot of text ',30)."...\n");
$pdf->SetDisplayMode('fullpage', 'single');
$pdf->save('javi.pdf');
$pdf->Output('',true);
?>
