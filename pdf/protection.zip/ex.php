<?php
define('FPDF_FONTPATH','font/');
require('fpdf_protection.php');

//$pdf=new FPDF_Protection();

$pdf =  FPDF_Protection::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'FPDF_Protection');

$pdf->SetProtection(array('print'));
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial');
$pdf->Write(10,'You can print me but not copy my text.');
$pdf->Output('',true);
?>
