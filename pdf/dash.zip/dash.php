<?php
/**
 * Based on the Dashes script by Yukihiro O (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
require('File/PDF.php');

class PDF extends File_PDF
{
	function SetDash($black=false,$white=false)
	{
		if($black and $white)
			$s=sprintf('[%.3f %.3f] 0 d',$black*$this->_scale,$white*$this->_scale);
		else
			$s='[] 0 d';
		$this->_out($s);
	}
}

?>
