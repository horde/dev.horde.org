<?php
require('dashed_rect.php');
$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->SetDrawColor('gray',200/255);
$pdf->DashedRect(40,10,165,40);
$pdf->SetFont('Arial','B',30);
$pdf->SetXY(40,10);
$pdf->Cell(125,30,'Enjoy dashes!',0,0,'C',0);
$pdf->Output('',true);
?>