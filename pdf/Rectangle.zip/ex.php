<?php
require('rounded_rect2.php');

$pdf =  PDF::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF');
$pdf->Open();
$pdf->AddPage();
$pdf->SetFillColor('grey',192/255);
$pdf->RoundedRect(60, 30, 68, 46, 5, 'DF', '13');
$pdf->Output('',true);
?>