<?php
/**
 * Based on the subWrite script by Wirus (http://www.fpdf.org/).
 * Translated to File_PDF class by Javier Mestre 
 */ 
require('File/PDF.php');

class PDF extends File_PDF
{
function subWrite($h, $txt, $link='',$subFontSize=12, $subOffset=0)
{
	// resize font
	$subFontSizeold = $this->_font_size_pt;
	$this->SetFontSize($subFontSize);

	// reposition y
	$subOffset = ((($subFontSize - $subFontSizeold) / $this->_scale) * 0.3) + ($subOffset / $this->_scale);
	$subX        = $this->x;
	$subY        = $this->y;
	$this->SetXY($subX, $subY - $subOffset);

	//Output text
	$this->Write($h, $txt, $link);

	// restore y position
	$subX        = $this->x;
	$subY        = $this->y;
	$this->SetXY($subX,  $subY + $subOffset);

	// restore font size
	$this->SetFontSize($subFontSizeold);
}
}
?>
