<?php
require_once 'pdf_codabar.php';


$pdf = PDF_Codabar::factory(array('orientation' => 'P',
                            'unit' => 'mm',
                            'format' => 'A4'),
                      'PDF_Codabar');
$pdf->AddPage();
$pdf->Codabar(75,40,'123456789');
$pdf->Output('',true);
?>
