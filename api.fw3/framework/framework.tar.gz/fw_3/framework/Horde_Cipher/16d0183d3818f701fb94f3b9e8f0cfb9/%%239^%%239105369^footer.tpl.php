<?php /* Smarty version 2.6.0, created on 2010-10-03 05:26:25
         compiled from footer.tpl */ ?>
<?php if (! $this->_tpl_vars['index']): ?>
	<p class="notes" id="credit">
		Documentation generated on <?php echo $this->_tpl_vars['date']; ?>
 by <a href="<?php echo $this->_tpl_vars['phpdocwebsite']; ?>
" target="_blank">phpDocumentor <?php echo $this->_tpl_vars['phpdocversion']; ?>
</a>
	</p>
<?php endif; ?>
	<?php if ($this->_tpl_vars['top3']): ?></div><?php endif; ?>
</body>
</html>